/*
 * time.c  Timer functions for the DSC21.
 *         
 * copyright:
 *         (C) 2001 RidgeRun, Inc. (http://www.ridgerun.com)
 * author: Gordon McNutt <gmcnutt@ridgerun.com>
 *
 * This program is free software; you can redistribute  it and/or modify it
 * under  the terms of  the GNU General  Public License as published by the
 * Free Software Foundation;  either version 2 of the  License, or (at your
 * option) any later version.
 *
 * THIS  SOFTWARE  IS PROVIDED   ``AS  IS'' AND   ANY  EXPRESS OR IMPLIED
 * WARRANTIES,   INCLUDING, BUT NOT  LIMITED  TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
 * NO  EVENT  SHALL   THE AUTHOR  BE    LIABLE FOR ANY   DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED   TO, PROCUREMENT OF  SUBSTITUTE GOODS  OR SERVICES; LOSS OF
 * USE, DATA,  OR PROFITS; OR  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * You should have received a copy of the  GNU General Public License along
 * with this program; if not, write  to the Free Software Foundation, Inc.,
 * 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

#include <linux/time.h>
#include <linux/timex.h>
#include <linux/types.h>
#include <linux/sched.h>
#include <asm/io.h>
#include <asm/arch/hardware.h>

extern unsigned long av3xx_gettimeoffset(void)
{
	u16 elapsed;

	/*
	 * Compute the elapsed count. The current count tells us how
	 * many counts remain until the next interrupt. LATCH tells us
	 * how many counts total occur between interrupts. Subtract to
	 * get the counts since the last interrupt.
	 */
	elapsed = LATCH - inb(AV3XX_TIMER0_BASE+AV3XX_TIMER_CNT);

	/* 
	 * Convert the elapsed count to usecs. I guess there are 'tick' usecs
	 * between every interrupt. 
	 */
	return (unsigned long)((elapsed * tick) / LATCH);
}

void av3xx_timer_interrupt(int irq, void *dev_id, struct pt_regs *regs)
{
	/* added by oxygen */
	//printk("In av3xx_timer_interrupt (%d)\n",jiffies);
	/******************/
	do_timer(regs);
}

