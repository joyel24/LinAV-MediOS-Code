/*
* asm/arch/av3xx_graphics.h
*
* linav - http://linav.sourceforge.net
* Copyright (c) 2004 by Christophe THOMAS
*
* All files in this archive are subject to the GNU General Public License.
* See the file COPYING in the source tree root for full license agreement.
* This software is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY
* KIND, either express of implied.
*
*/

#ifndef __ASM_ARCH_AV3XX_KBD_TST_H
#define __ASM_ARCH_AV3XX_KBD_TST_H

/*#define        BUTTONS_AV300_UP            0x0001
#define        BUTTONS_AV300_LEFT          0x0002
#define        BUTTONS_AV300_RIGHT         0x0010
#define        BUTTONS_AV300_DOWN          0x0020
#define        BUTTONS_AV300_MENU3         0x0040
#define        BUTTONS_AV300_MENU1         0x0100
#define        BUTTONS_AV300_MENU2         0x0200
#define        BUTTONS_AV300_JOYPRESS      0x0400
#define        BUTTONS_AV300_ON            0x1000
#define        BUTTONS_AV300_OFF           0x2000
#define        BUTTONS_AV300_ANY           0x3773*/

#define        BUTTONS_AV300_UP            0x0000
#define        BUTTONS_AV300_LEFT          0x0001
#define        BUTTONS_AV300_RIGHT         0x0002
#define        BUTTONS_AV300_DOWN          0x0003
#define        BUTTONS_AV300_MENU3         0x0004
#define        BUTTONS_AV300_MENU1         0x0005
#define        BUTTONS_AV300_MENU2         0x0006
#define        BUTTONS_AV300_JOYPRESS      0x0007
#define        BUTTONS_AV300_ON            0x0008
#define        BUTTONS_AV300_OFF           0x0009

#define        STEP_SIZE                   1

int av3xx_chk_button(unsigned long ptr);
int av3xx_button_state();
int av3xx_button_init(void);
void av3xx_move_mouse(int but);
int av3xx_button_get_mouse(struct av3xx_pos * pos);
int av3xx_button_set_mouse(struct av3xx_pos * pos);

#endif
