/*

 All files in this archive are subject to the GNU General Public License.
 See the file COPYING in the source tree root for full license agreement.
 This software is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY
 KIND, either express of implied.

 AIC23 audio codec access

 Date:     01/11/2005
 Author:   GliGli

*/

#include <aic23.h>

void aic23WriteReg(int address,int value){
  char val;
  val=value;

  i2cWrite(AIC23_I2C_ADDRESS,(address<<1)|(value>>8),&val,1);
}

void aic23Init(){
  aic23WriteReg(15,0x00); //reset
  aic23WriteReg(4,0x12); //analog audio path: dac selected & mic muted
  aic23WriteReg(5,0x00); //digital audio path: nothing
  aic23WriteReg(6,0x07); //power down control: activate everything but input
  aic23WriteReg(7,0x43); //digital audio interface: master mode & dsp data format
  aic23WriteReg(8,0x23); //sample rate control: 44khz & oversampling & USB mode
  aic23WriteReg(9,0x01); //activate digital interface
}

void aic23Shutdown(){
  aic23WriteReg(2,0x180); //output volume = 0
  aic23WriteReg(9,0x00); //deactivate digital interface
  aic23WriteReg(6,0xff); //power down control: shutdown everything
}

void aic23SetOutputVolume(int volume,int channel){
  switch (channel){
    case AIC23_CHANNEL_BOTH:
      aic23WriteReg(2,volume | 0x180);
      break;
    case AIC23_CHANNEL_LEFT:
      aic23WriteReg(2,volume | 0x80);
      break;
    case AIC23_CHANNEL_RIGHT:
      aic23WriteReg(3,volume | 0x80);
      break;
  }
}
