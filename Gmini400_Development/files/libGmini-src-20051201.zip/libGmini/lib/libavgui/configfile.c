/*

 All files in this archive are subject to the GNU General Public License.
 See the file COPYING in the source tree root for full license agreement.
 This software is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY
 KIND, either express of implied.

 Configuration file reader/writer

 Date:     08/10/2005
 Author:   GliGli

*/

#include <configfile.h>

char configfileContent[MAX_CONFIGFILE_LENGTH];

void configClear(){
  memset(configfileContent,'\0',MAX_CONFIGFILE_LENGTH);
}

int configLoad(const char * fn){
  int cf;

  cf=open(fn,O_RDWR);

  if(cf>=0){
    configClear();
    read(cf,configfileContent,MAX_CONFIGFILE_LENGTH);
    close(cf);
    return true;
  }

  return false;
}

int configSave(const char * fn){
  int cf;

  cf=creat(fn,O_CREAT);

  if(cf>=0){
    write(cf,configfileContent,strlen(configfileContent));
    close(cf);
    return true;
  }

  return false;
}

void configTrim(char *s){
  char *p;

  // trim left
  p=s;
  while(*p==' ' || *p=='"') ++p;
  strcpy(s,p);

  //trim right
  p=s+strlen(s)-1;
  while(*p==' ' || *p=='"') --p;
  *(p+1)='\0';
}


bool configReadString(const char * name,char * value){
  bool found;
  char linename[50];
  char *linepp;
  char *linep;
  char *valp;
  char *valend;

  linep=configfileContent;
  linepp=0;
  found=true;

  while(found){
    if ((linep-linepp>1) && (*linep!='#')){ // continue only if there is something between delimiters & skip comments
      valp=strpbrk(linep,"=\r\n");
      if (*valp=='='){ // continue only if = is found before reaching line end
        strncpy(linename,linep,valp-linep);
        linename[valp-linep]='\0';
        configTrim(linename);

        if(!strcmp(name,linename)){ // is this the line we are looking for?
          ++valp;
          valend=strpbrk(valp,"\r\n");
          if(valend){ // valend will be NULL if this is the last line of the config file
            strncpy(value,valp,valend-valp);
            value[valend-valp]='\0';
          }else{
            strcpy(value,valp);
          }
          configTrim(value);

          return true;
        }
      }
    }

    linepp=linep;
    linep=strpbrk(linepp,"\r\n");
    found=linep!=NULL;
    linep+=2;
  }

  return false;
}

int configReadInt(const char * name){
  char str[255];
  int val=-1;

  if(configReadString(name,str))
    sscanf(str,"%d",&val);

  return val;
}

bool configReadBool(const char * name){
  return configReadInt(name)!=0;
}

bool configRemoveValue(const char * name){
  bool found;
  char linename[50];
  char *linepp;
  char *linep;
  char *valp;
  char *valend;

  linep=configfileContent;
  linepp=0;
  found=true;

  while(found){
    if ((linep-linepp>1) && (*linep!='#')){ // continue only if there is something between delimiters & skip comments
      valp=strpbrk(linep,"=\r\n");
      if (*valp=='='){ // continue only if = is found before reaching line end
        strncpy(linename,linep,valp-linep);
        linename[valp-linep]='\0';
        configTrim(linename);

        if(!strcmp(name,linename)){ // is this the line we are looking for?
          ++valp;
          valend=strpbrk(valp,"\r\n");

          while(valend && (*valend=='\r' || *valend=='\n')) ++valend; // also remove the line end

          if(valend){ // valend will be NULL if this is the last line of the config file
            strcpy(linep,valend);
          }else{
            *linep='\0';
          }
          return true;
        }
      }
    }

    linepp=linep;
    linep=strpbrk(linepp,"\r\n");
    found=linep!=NULL;
    linep+=2;
  }

  return false;
}


void configWriteString(const char * name,const char * value){
  char str[255];

  configRemoveValue(name);

  snprintf(str,255,"%s=%s\r\n",name,value);
  strcat(configfileContent,str);
}

void configWriteInt(const char * name,int value){
  char str[255];

  configRemoveValue(name);

  snprintf(str,255,"%s=%d\r\n",name,value);
  strcat(configfileContent,str);
}

void configWriteBool(const char * name,bool value){
  configWriteInt(name,value?1:0);
}
