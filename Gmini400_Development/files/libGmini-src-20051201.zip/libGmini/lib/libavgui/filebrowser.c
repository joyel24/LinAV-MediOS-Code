/*

 All files in this archive are subject to the GNU General Public License.
 See the file COPYING in the source tree root for full license agreement.
 This software is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY
 KIND, either express of implied.

 Browse for file dialog

 Date:     20/09/2005
 Author:   GliGli

*/

#include <filebrowser.h>

#define BFF_BACK_COLOR  0
#define BFF_TEXT_COLOR  1
#define BFF_SEL_COLOR   2
#define BFF_PATH_COLOR  3

int default_bff_colors[] = {COL_TRANS, COL_WHITE, COL_BLUE, COL_DARKGREY};

int filesCompare (const void * a, const void * b ){
  bool aisdir,bisdir;

  aisdir=((tDirItem *) a)->isdir;
  bisdir=((tDirItem *) b)->isdir;

  // put dirs on the top of the list
  if(aisdir && !bisdir) return -1;
  if(!aisdir && bisdir) return 1;

  return strcasecmp(((tDirItem *) a)->name,((tDirItem *) b)->name);
}

bool browseForFile(char * fn,struct graphicsBuffer *osd,struct graphicsBuffer *fnt,char ** fntdat,int colors[]) {
  int i,y,start,end,filecount,selidx,key,oldkey,namelen;

  DIR *dd;
  struct dirent *di;

  char curdir[255]="/";
  char cutname[255];
  
  char * filetoselect = 0;

  static tDirItem files[MAX_FILES_IN_DIR];
  bool filefound,abort,diok;

  int ** oldpal;
  int pal[2];

  int numlines=(osd->height/fnt->height)-1;
  int totalwidth=osd->width;
  int filex=2*fnt->width;
  int maxnamelen=(osd->width/fnt->width)-2;

  if(!colors) colors=default_bff_colors;

  pal[0]=colors[BFF_BACK_COLOR];
  pal[1]=colors[BFF_TEXT_COLOR];

  // replace the font pallette with the local pallette
  oldpal=fnt->pallette16;
  fnt->pallette16=(int**)pal;

  // if fn is a valid path/name use it as the default directory/selected file
  if(strlen(fn)){
    char * lastdelim;

    lastdelim=strrchr(fn,'/');
    if (lastdelim){
      int lastdelimpos = lastdelim-fn+1;

      // set the current dir
      memset(curdir,'\0',255);
      strncpy(curdir,fn,lastdelimpos);
      // if fn contains a filename
      if(lastdelimpos<strlen(fn)){
        filetoselect=lastdelim+1;
      }
    }
  }

  filefound=false;
  abort=false;
  oldkey=-1;
  do{
    graphicsBoxfA(osd, 0, 0, totalwidth, osd->height, colors[BFF_BACK_COLOR]);

    pal[0]=colors[BFF_PATH_COLOR];

    namelen=strlen(curdir);
    if (namelen<=maxnamelen){
      graphicsStringA(osd, 0, 0, fnt, fntdat, fnt->width, 0,curdir);
    }else{
      strcpy(cutname,&curdir[namelen-(osd->width/fnt->width)]);
      graphicsStringA(osd, 0, 0, fnt, fntdat, fnt->width, 0,cutname);
    }

    // wait msg
    pal[0]=colors[BFF_BACK_COLOR];
    graphicsStringA(osd, 0, fnt->height, fnt, fntdat, fnt->width, 0,"(loading...)");

    //reading dir content
    filecount=0;
    diok=true;
    dd=opendir(curdir);
    do{
      di=readdir(dd);
      if (di){
        if (strcmp(di->d_name,".")){ // remove . directory
          files[filecount].isdir=(di->attribute & ATTR_DIRECTORY)!=0;
          strcpy(files[filecount].name,di->d_name);

          ++filecount;
        }
      }else{
        diok=false;
      }
    }while(diok && filecount<MAX_FILES_IN_DIR);
    closedir(dd);

    // sorting the list
    qsort(files,filecount,sizeof(tDirItem),filesCompare);

    selidx=0;

    // pre-selection of the file
    if (filetoselect){
      for(i=0;i<filecount;++i){
        if(!strcmp(files[i].name,filetoselect)){
          selidx=i;
          filetoselect=0;
          memset(fn,'\0',255);
          break;
        }
      }
    }

    // clear wait msg
    graphicsStringA(osd, 0, fnt->height, fnt, fntdat, fnt->width, 0,"            ");

    for(;;){
      // drawing
      start=0;
      if (filecount>numlines){
        if (selidx>filecount-numlines/2){
          start=filecount-numlines;
        }else if (selidx>=numlines/2){
          start=selidx-numlines/2;
        }
      }
      end=filecount;
      if (end>numlines) end=start+numlines;

      y=fnt->height;
      for(i=start;i<end;++i){
        pal[0]=colors[BFF_BACK_COLOR];


        if (files[i].isdir)
          graphicsStringA(osd, 0, y, fnt, fntdat, fnt->width, 0,"D");
        else
          graphicsStringA(osd, 0, y, fnt, fntdat, fnt->width, 0," ");

        if (i==selidx) pal[0]=colors[BFF_SEL_COLOR];

        namelen=strlen(files[i].name);
        if (namelen<maxnamelen) graphicsBoxfA(osd, filex+namelen*fnt->width, y, osd->width-(filex+namelen*fnt->width), fnt->height, colors[BFF_BACK_COLOR]);

        memset(cutname,'\0',255);
        strncpy(cutname,files[i].name,maxnamelen);
        graphicsStringA(osd, filex, y, fnt, fntdat, fnt->width, 0,cutname);

        y+=fnt->height;
      }

      graphicsBoxfA(osd, 0, y, totalwidth, osd->height-y, colors[BFF_BACK_COLOR]);

      // key handling
      key=buttonsWaitAndRepeat(5000,1000,20000);

      if (key & BUTTONS_GM400_UP) --selidx;
      if (key & BUTTONS_GM400_DOWN) ++selidx;
      if (key & BUTTONS_GM400_OFF){
        abort=true;
        break;
      }
      if (key & BUTTONS_GM400_LEFT){
        appendDirToPath(curdir,"..");
        break;
      }
      if (key & BUTTONS_GM400_SQUARE || key & BUTTONS_GM400_RIGHT){
        filefound=!files[selidx].isdir;
        if (filefound){
          strcat(curdir,files[selidx].name);
        }else{
          appendDirToPath(curdir,files[selidx].name);
        }
        break;
      }


      // make sure selection does not go off limits
      selidx=(selidx<0)?filecount-1:selidx;
      selidx=(selidx>=filecount)?0:selidx;
    }
  }while (!filefound && !abort);
  if (!abort) strcpy(fn,curdir);

  // restore the original font pallette
  fnt->pallette16=oldpal;

  // make sure no button is pressed before quitting
  while((buttonsGetStatusA()&BUTTONS_GM400_ANY)!=0) delay(100);

  return !abort;
}

void appendDirToPath(char * path,char * dir){
  if (dir[0]=='.' && dir[1]=='.'){
    int i=strlen(path);
    int delimcount=0;

    while(i>=0 && delimcount<2){
      if (path[i]=='/'){
        ++delimcount;

        if(delimcount>1){
          path[i+1]='\0';
        }
      }
      --i;
    }
  }else if (dir[0]=='.'){
    return;
  }else{
    strcat(path,dir);
    strcat(path,"/");
  }
}
