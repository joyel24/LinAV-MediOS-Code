/* video.h
   Copyright 2004, the Avos project.

   This file is free software; we give unlimited permission to copy
   and/or distribute it, with or without modifications, as long as this
   notice is preserved.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY, to the extent permitted by law; without
   even the implied warranty of MERCHANTABILITY or FITNESS FOR A
   PARTICULAR PURPOSE.
*/
#ifndef _VIDEO_H
#define _VIDEO_H

#include <gio.h>
#include <stdbool.h>
#include <system.h>

#define REG_VIDEO_MODE (*(REG 0x30800))
#define GIO_TVOUT 18

#define VIDEO_MODE_NONINTERLACED    0x4000
#define VIDEO_MODE_INTERLACED       0x0000
#define VIDEO_MODE_PAL              0x8000
#define VIDEO_MODE_NTSC             0x0000

void videoEnableTvOut(bool enabled);
void videoSetTvOutMode(int mode);

#endif

