libGmini 0.1
by GliGli

Setup:

  -run 'make' in the root folder.
  -in 'Makefile.conf' adjust BIN2WAV and BIN2WAV_TEMPLATE to point to the
    bin2wavxploit subfolder files.

Folders:

  _old: Old stuff for the AV300
  bin2wavxploit: tools to create .bin.wav files
  docs: Old AV300 documentation, most of it is still true for the Gmini
  include: library header files
  lib: library sourcecode
  myapps: programs i wrote using this library, most are terst programs except
    the SMS/GG emulator
  stub: needed for c apps

Toolchain to build under cygwin:

  http://oxygen77.free.fr/linav/files/toolchain/toolchain_arm_nofpu.zip
  (unzip to /usr/local and add /usr/local/toolchain_arm_nofpu/bin to PATH)

Credits:

  libGmini is mostly based on libAVOS written by DoggerMoore, awksedgrep and
    oxygen77 for the AV300 (http://sourceforge.net/projects/avos).
  i2c & dsp code is from the Gravity OS project written by oxygen77 and redpanther
    (http://linav.free.fr).
  fat/file/dir code is from the Rockbox project (http://rockbox.org).

Licence:
  
  GNU GPL