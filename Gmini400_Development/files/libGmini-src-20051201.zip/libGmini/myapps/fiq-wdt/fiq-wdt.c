/*

 All files in this archive are subject to the GNU General Public License.
 See the file COPYING in the source tree root for full license agreement.
 This software is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY
 KIND, either express of implied.

 Test program for the file browser

 Date:     11/10/2005
 Author:   GliGli

*/

#include "string.h"
#include <ata.h>
#include <fat.h>
#include <file.h>
#include <system.h>
#include <graphics.h>
#include <osdDSC25.h>
#include <buttons.h>
#include <fonts.h>
#include <debug.h>
#include <usb.h>
#include <timers.h>

#include <filebrowser.h>
#include <tickcount.h>

__attribute__ ((section(".cored"))) int dummy;

char _real_iram_start;
char _iram_start;
char _iram_end;

void copyIramContent();
int main(){
  // dis irq
  asm(
    "mrs r0,cpsr;"
    "orr r0,r0,#0x80;"
    "msr cpsr_cf,r0;"
  );

  // dis fiq
  asm(
    "mrs r0,cpsr;"
    "orr r0,r0,#0x40;"
    "msr cpsr_cf,r0;"
  );

  copyIramContent();

  // en fiq
  asm(
    "mrs r0,cpsr;"
    "bic r0, r0, #0x40;"
    "msr cpsr_cf,r0;"
  );

  while(!(buttonsGetStatusA()&BUTTONS_GM400_ON));

  return 0;
}

void copyIramContent(){
  unsigned char *iram,*iram_end,*sdram;
  int len;

	iram=&_iram_start;
  iram_end=&_iram_end;
  len=(iram_end-iram) + 1;
  sdram=&_real_iram_start;

  debug("copyIramContent() iram=%0.8X sdram=%0.8X len=%d\n",&_iram_start,&_real_iram_start,len);

  for(;len;--len){
    *iram++=*sdram++;
  }
}


