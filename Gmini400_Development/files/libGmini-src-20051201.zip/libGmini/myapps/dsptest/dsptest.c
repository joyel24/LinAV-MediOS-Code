/*

 All files in this archive are subject to the GNU General Public License.
 See the file COPYING in the source tree root for full license agreement.
 This software is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY
 KIND, either express of implied.

 DSP/AIC23 codec test

 Date:     11/10/2005
 Author:   GliGli

*/

#include "string.h"
#include <ata.h>
#include <fat.h>
#include <file.h>
#include <system.h>
#include <graphics.h>
#include <osdDSC25.h>
#include <buttons.h>
#include <fonts.h>
#include <debug.h>
#include <usb.h>
#include <timers.h>
#include <dsp.h>
#include <aic23.h>

#include <filebrowser.h>
#include <tickcount.h>
#include <configfile.h>


#define LCD_WIDTH 220
#define LCD_HEIGHT 176

#define OSD_BITMAP1_WIDTH 240
#define OSD_BITMAP1_HEIGHT 176

#define OSD_BITMAP1_ADDRESS 0x018d1500

#define WAVE_PERIOD ((volatile unsigned short *)0x40100)
#define DEBUG_MSG_STATE ((volatile unsigned short *)0x40102)
#define DEBUG_MSG_TEXT  ((short *)0x40104)

static struct graphicsBuffer osdBmp1;

static int pal[2] = {0x0000, 0xffff};


static struct graphicsBuffer f5x7  = {0, 1, 5, 7, 1, 0, -1, 0, 0, 0, 0, (int**) &pal, (int**) NULL};
static struct graphicsBuffer f6x9  = {0, 1, 6, 9, 1, 0, -1, 0, 0, 0, 0, (int**) &pal, (int**) NULL};
//static struct graphicsBuffer f8x13 = {0, 1, 8, 13, 1, 0, -1, 0, 0, 0, 0, (int**) &pal, (int**) NULL};

void initDisplay();
void initHDD();

int main(){
  char str[100];
  int i,b;
  char volume=96;

  initTickCount();
  initDisplay();
  initHDD();

  load_dsp_program_hdd("/test.out");

  *WAVE_PERIOD=64;
  *DEBUG_MSG_STATE=0;

  dsp_run();

  debug("\n\n");

  aic23Init();

  graphicsStringA(&osdBmp1, 0, 0, &f6x9, std6x9_, 6, 0,"-= DSP/CODEC TEST =-");
  graphicsStringA(&osdBmp1, 0, 10, &f5x7, std5x7_, 5, 0,"(up/down: volume square/cross: freq)");

  do{
    b=buttonsGetStatusA();

    if(b&BUTTONS_GM400_UP){
      volume++;
    }
    if(b&BUTTONS_GM400_DOWN){
      volume--;
    }

    if(b&BUTTONS_GM400_SQUARE){
      (*WAVE_PERIOD)--;
    }
    if(b&BUTTONS_GM400_CROSS){
      (*WAVE_PERIOD)++;
    }

    aic23SetOutputVolume(volume,AIC23_CHANNEL_BOTH);
    delay(1000);

    if(*DEBUG_MSG_STATE){
      for(i=0;i<100;++i){
        str[i]=DEBUG_MSG_TEXT[i];
      }
      debug("%s\n",str);
      *DEBUG_MSG_STATE=0;
    }

    sprintf(str,"Frequency: %d Hz     ",22050/(*WAVE_PERIOD));
    graphicsStringA(&osdBmp1, 0, 30, &f6x9, std6x9_, 6, 0,str);
    sprintf(str,"Volume: %d  ",volume);
    graphicsStringA(&osdBmp1, 0, 40, &f6x9, std6x9_, 6, 0,str);
  }while(!(b&BUTTONS_GM400_OFF));

  aic23Shutdown();

  return 1;
}

void initDisplay(){

  osdSetComponentConfigA(OSD_VIDEO1, 0);
  osdSetComponentConfigA(OSD_VIDEO1, 0);
  osdSetComponentConfigA(OSD_BITMAP1, 0);
  osdSetComponentConfigA(OSD_BITMAP2, 0);
  osdSetComponentConfigA(OSD_CURSOR1, 0);
  osdSetComponentConfigA(OSD_CURSOR2, 0);

  osdBmp1.offset = OSD_BITMAP1_ADDRESS;
  osdBmp1.bytesPerLine = OSD_BITMAP1_WIDTH*2;
  osdBmp1.width = LCD_WIDTH;
  osdBmp1.height = OSD_BITMAP1_HEIGHT;
  osdBmp1.bitsPerPixelShift = 4;
  osdBmp1.bitsPerPixel = 16;

  graphicsBoxfA(&osdBmp1,0,0,OSD_BITMAP1_WIDTH,OSD_BITMAP1_HEIGHT,0x0000);

  osdSetMainConfigA(1);
  osdSetBacklightA(1);

  osdSetComponentSizeA(OSD_BITMAP1, OSD_BITMAP1_WIDTH*2, OSD_BITMAP1_HEIGHT);
  osdSetComponentPositionA(OSD_BITMAP1, 0xfc, 0x18);
  osdSetComponentOffsetA(OSD_BITMAP1, OSD_BITMAP1_ADDRESS);
  osdSetComponentSourceWidthA(OSD_BITMAP1, 0xf);
  osdSetComponentConfigA(OSD_BITMAP1, OSD_COMPONENT_ENABLE
                                   | OSD_BITMAP_8BIT
                                   | OSD_BITMAP_0TRANS
                                   );


}

void initHDD(){
    int c;

    ataSelectHDDA();
    for (c=0;c<0x1000;c++) {}

    ataPowerUpHDDA();
    ataResetHDDA();
    for (c=0;c<0x24000;c++) {}

    ataReadMBR();

    fat_init();
    fat_mount(getPartition(0)->start);
};

void drawProgress(int offset,int length,int mode){};
