#include <stdio.h>

#include <csl.h>
#include <csl_mcbsp.h>
#include <csl_irq.h>

#include <string.h>

#define WAVE_PERIOD 	((volatile unsigned short *)0x80)
#define DEBUG_MSG_STATE ((volatile unsigned short *)0x81)
#define DEBUG_MSG_TEXT  ((char *)0x82)

static MCBSP_Config DataPortCfg= {
  0x0000,0x0200, /* SPCR : free running mode */
  0x00A0,0x0001, /* RCR  : 32 bit receive data length */  
  0x00A0,0x0000, /* XCR  : 32 bit transmit data length */            
  0x0000,0x3000,  
  0x0000,0x0000, /* MCR  : single channel */
  0x000E, 	 	   /* PCR  : FSX, FSR active low, external FS/CLK source */
  0x0000,
  0x0000,
  0x0000,
  0x0000
};     

void debug(const char* msg);

void main(){
 	MCBSP_Handle DataPort;
	int i;
	int p=16;

	debug("DSP START");

	CSL_init();

	DataPort = MCBSP_open(MCBSP_PORT0, MCBSP_OPEN_RESET);
	if (DataPort==INV) debug("Data Port NOK");

	MCBSP_config(DataPort,&DataPortCfg);

	MCBSP_start(DataPort,MCBSP_XMIT_START,0);

	for(;;){
		p=*WAVE_PERIOD;
		for(i=0;i<p;++i){
			while(!MCBSP_xrdy(DataPort));
	    	MCBSP_write32(DataPort,0x80008000);
		}
		for(i=0;i<p;++i){
			while(!MCBSP_xrdy(DataPort));
	    	MCBSP_write32(DataPort,0x80018001);
		}
	}
}

void debug(const char* msg){
	strcpy(DEBUG_MSG_TEXT,msg);
	*DEBUG_MSG_STATE=1;
	while(*DEBUG_MSG_STATE);
}
