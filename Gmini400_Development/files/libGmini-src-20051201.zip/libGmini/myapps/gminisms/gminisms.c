/*

 All files in this archive are subject to the GNU General Public License.
 See the file COPYING in the source tree root for full license agreement.
 This software is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY
 KIND, either express of implied.

 SMS/GG emulator (port of SMS Plus by Charles Mac Donald)

 Date:     11/10/2005
 Author:   GliGli

*/

#include "string.h"
#include <ata.h>
#include <fat.h>
#include <file.h>
#include <system.h>
#include <graphics.h>
#include <osdDSC25.h>
#include <buttons.h>
#include <fonts.h>
#include <debug.h>
#include <timers.h>
#include <uart.h>
#include <aic23.h>
#include <dsp.h>
#include <video.h>

#include <configfile.h>
#include <filebrowser.h>
#include <menu.h>
#include <colors.h>

#include "shared.h"

#include "pic_loading.h"
#include "pic_help.h"
#include "pic_background.h"

#define REG_ARM_CLOCK     (REG 0x30880)

#define REG_LCD_VSYNC     (REG 0x3082C)
#define REG_LCD_BACKLIGHT (REG 0x308A8)

#define LCD_WIDTH          220
#define LCD_HEIGHT         176

#define OSD_VIDEO1_WIDTH   240
#define OSD_VIDEO1_HEIGHT  176

#define OSD_BITMAP1_WIDTH  256
#define OSD_BITMAP1_HEIGHT 192

#define OSD_BITMAP2_WIDTH  240
#define OSD_BITMAP2_HEIGHT 176

#define OSD_VIDEO1_CONFIG   OSD_COMPONENT_ENABLE
#define OSD_BITMAP1_CONFIG  OSD_COMPONENT_ENABLE | OSD_BITMAP_8BIT | OSD_BITMAP_MERGEBACK | OSD_BITMAP_A7 | OSD_BITMAP_ZX1 | OSD_BITMAP_RAMCLUT
#define OSD_BITMAP2_CONFIG  OSD_COMPONENT_ENABLE | OSD_BITMAP_8BIT | OSD_BITMAP_0TRANS
#define OSD_CURSOR1_CONFIG  OSD_COMPONENT_ENABLE | 7<<OSD_CURSOR1_BORDERHEIGHT_SHIFT | 7<<OSD_CURSOR1_BORDERWIDTH_SHIFT | OSD_CURSOR1_RAMCLUT | 0<<OSD_CURSOR1_COLOR_SHIFT

#define OSD_VIDEO1_ADDRESS    0x01870000
#define OSD_BITMAP1_ADDRESS   0x018b0000
#define OSD_BITMAP1_ADDRESS_2 0x018c0000
#define OSD_BITMAP2_ADDRESS   0x018d1500

#define LCD_POS_X 252
#define LCD_POS_Y 1

#define PAL_POS_X 220
#define PAL_POS_Y 50

#define NTSC_POS_X 212
#define NTSC_POS_Y 28

#define MAX_VS_POS_X 72
#define MAX_VS_POS_Y 16

#define MAX_ROM_SIZE 1024*1024
#define SMS_BANK_SIZE 16384

#define TICKS_PER_FRAME 167

#define CONFIG_FILE "/System/GminiSMS.cfg"

// sections pointers
char _real_iram_start;
char _iram_start;
char _iram_end;
char _binary_dspcode_gminisms_dsp_out_start;
char _binary_dspcode_gminisms_dsp_out_end;

struct graphicsBuffer osdBmp1;
struct graphicsBuffer osdBmp1_2;
struct graphicsBuffer osdBmp2;

int pal[2] = {COL_TRANS, COL_WHITE};

//static struct graphicsBuffer f5x7  = {0, 1, 5, 7, 1, 0, -1, 0, 0, 0, 0, (int**) pal, (int**) NULL};
struct graphicsBuffer f6x9  = {0, 1, 6, 9, 1, 0, -1, 0, 0, 0, 0, (int**) pal, (int**) NULL};
struct graphicsBuffer f8x13 = {0, 1, 8, 13, 1, 0, -1, 0, 0, 0, 0, (int**) pal, (int**) NULL};

int vsPosX=0;
int vsPosY=0;

bool autoFrameSkip;
int  frameSkip;
bool ggBorder;
bool swapButtons;
int tvOut;

tMenuItem ingameMenu[]={
  {"Sound:",ITEMTYPE_DUMMY,0,0,0},
  {"Volume",ITEMTYPE_INTEGER,0,0,100},
  {"",ITEMTYPE_DUMMY,0,0,0},
  {"Picture:",ITEMTYPE_DUMMY,0,0,0},
  {"Backlight power",ITEMTYPE_INTEGER,0,0,31},
  {"TV Out (pal/ntsc)",ITEMTYPE_INTEGER,0,0,2},
  {"",ITEMTYPE_DUMMY,0,0,0},
  {"Buttons:",ITEMTYPE_DUMMY,0,0,0},
  {"Swap buttons",ITEMTYPE_BOOLEAN,0,0,0},
  {"",ITEMTYPE_DUMMY,0,0,0},
  {"State saving:",ITEMTYPE_DUMMY,0,0,0},
  {"Slot",ITEMTYPE_INTEGER,1,1,10},
  {"Load state",ITEMTYPE_ACTION,2,0,0},
  {"Save state",ITEMTYPE_ACTION,3,0,0},
  {"",ITEMTYPE_DUMMY,0,0,0},
  {"Advanced options",ITEMTYPE_ACTION,4,0,0},
  {"",ITEMTYPE_DUMMY,0,0,0},
  {"Return to game",ITEMTYPE_ACTION,1,0,0}
};

tMenuItem advancedMenu[]={
  {"Frame skip options:",ITEMTYPE_DUMMY,0,0,0},
  {"Auto frame skip",ITEMTYPE_BOOLEAN,0,0,0},
  {"Frame skip",ITEMTYPE_INTEGER,0,0,10},
  {"",ITEMTYPE_DUMMY,0,0,0},
  {"Emulation options:",ITEMTYPE_DUMMY,0,0,0},
  {"Sprite limit",ITEMTYPE_BOOLEAN,0,0,0},
  {"Expand GG screen",ITEMTYPE_BOOLEAN,0,0,0},
  {"CPU cycles / line",ITEMTYPE_INTEGER,0,0,512},
  {"",ITEMTYPE_DUMMY,0,0,0},
  {"Gmini overclock (at your own risk!):",ITEMTYPE_DUMMY,0,0,0},
  {"Enable overclock",ITEMTYPE_BOOLEAN,0,0,0},
  {"Overclock rate",ITEMTYPE_INTEGER,0,0,5},
  {"",ITEMTYPE_DUMMY,0,0,0},
  {"Standard options",ITEMTYPE_ACTION,1,0,0}
};

char romname[256];

void copyIramContent();

void initDisplay();
void initHDD();
void initDSP();
void initCodec();

void clearOSD(int osd);
void showOSD(int osd);

void setTvOutMode(int mode);

void loadPicture(unsigned long * data);
void waitIntroKeyPress();

void initSmsEmul();
bool loadRom(char *romname);
void doEmulLoop();

void setVirtualScreenPos();
void moveVirtualScreen();

void showGGBorder(bool show);

void doIngameMenu();

void overclockARM(int rate);
void setBacklightPower(int power);

void loadDefaultConfig();
void applyConfig();

void loadSaveState(int slot,bool save);
void loadSaveSram(bool save);

void prepareHDDAccess();
void endHDDAccess();

int main(){
  initDisplay();
  loadPicture(pic_loading_data);

  // dis irq
  asm(
    "mrs r0,cpsr;"
    "orr r0,r0,#0x80;"
    "msr cpsr_cf,r0;"
  );

  // init
  initTickCount();
  copyIramContent();
  bpool(0x1000000,0x800000);
  initHDD();
  initDSP();
  initCodec();
  initSmsEmul();

  loadDefaultConfig();
  configLoad(CONFIG_FILE);

  // default values if config file exists
  if (configReadInt("Volume")==-1) configWriteInt("Volume",75);
  if (configReadInt("Backlight")==-1) configWriteInt("Backlight",31);
  if (configReadInt("TVOut")==-1) configWriteInt("TVOut",0);

  applyConfig();

  memset(romname,'\0',255);

  loadPicture(pic_help_data);
  waitIntroKeyPress();

  loadPicture(pic_background_data);

  for(;;){
    showOSD(OSD_BITMAP2);

    if (!browseForFile(romname,&osdBmp2,&f6x9,std6x9_,NULL)) break;

    if (!loadRom(romname)) continue;

    system_reset();

    loadSaveSram(false);

    osdSetPalletteA(0x00,0x80,0x80,0); //set color #0 to black
    clearOSD(OSD_BITMAP1);
    showOSD(OSD_BITMAP1);

    endHDDAccess();

    applyConfig();

    // center virtual screen
    vsPosX=MAX_VS_POS_X/2;
    vsPosY=MAX_VS_POS_Y/2;
    setVirtualScreenPos();

    doEmulLoop();

    *PSG_ENABLED=0;

    prepareHDDAccess();

    if(sms.save) loadSaveSram(true);
  }

  *DSP_STOP=1; //stop the DSP
  aic23Shutdown(); //stop the codec

  configSave(CONFIG_FILE);

  clearOSD(OSD_BITMAP2);
  graphicsStringA(&osdBmp2, 0, 0, &f8x13, std8x13_, 8, 0,"That's all folks ;)");

  videoEnableTvOut(false);

  return 1;
}
void copyIramContent(){
  unsigned char *iram,*iram_end,*sdram;
  int len;

  iram=&_iram_start;
  iram_end=&_iram_end;
  len=(iram_end-iram) + 1;
  sdram=&_real_iram_start;

  debug("copyIramContent() iram=%0.8X sdram=%0.8X len=%d\n",&_iram_start,&_real_iram_start,len);

  for(;len;--len){
    *iram++=*sdram++;
  }
}

void initDisplay(){
  osdSetComponentConfigA(OSD_VIDEO1, 0);
  osdSetComponentConfigA(OSD_VIDEO2, 0);
  osdSetComponentConfigA(OSD_BITMAP1, 0);
  osdSetComponentConfigA(OSD_BITMAP2, 0);
  osdSetComponentConfigA(OSD_CURSOR1, 0);
  osdSetComponentConfigA(OSD_CURSOR2, 0);

  osdBmp1.offset = OSD_BITMAP1_ADDRESS;
  osdBmp1.bytesPerLine = OSD_BITMAP1_WIDTH;
  osdBmp1.width = OSD_BITMAP1_WIDTH;
  osdBmp1.height = OSD_BITMAP1_HEIGHT;
  osdBmp1.bitsPerPixelShift = 4;
  osdBmp1.bitsPerPixel = 8;

  osdBmp1_2.offset = OSD_BITMAP1_ADDRESS_2;
  osdBmp1_2.bytesPerLine = OSD_BITMAP1_WIDTH;
  osdBmp1_2.width = OSD_BITMAP1_WIDTH;
  osdBmp1_2.height = OSD_BITMAP1_HEIGHT;
  osdBmp1_2.bitsPerPixelShift = 4;
  osdBmp1_2.bitsPerPixel = 8;

  osdBmp2.offset = OSD_BITMAP2_ADDRESS;
  osdBmp2.bytesPerLine = OSD_BITMAP2_WIDTH*2;
  osdBmp2.width = LCD_WIDTH;
  osdBmp2.height = OSD_BITMAP2_HEIGHT;
  osdBmp2.bitsPerPixelShift = 4;
  osdBmp2.bitsPerPixel = 16;

  clearOSD(OSD_BITMAP1);
  clearOSD(OSD_BITMAP2);

  osdSetComponentSizeA(OSD_VIDEO1, OSD_VIDEO1_WIDTH*2, OSD_VIDEO1_HEIGHT);
  osdSetComponentOffsetA(OSD_VIDEO1, OSD_VIDEO1_ADDRESS);
  osdSetComponentSourceWidthA(OSD_VIDEO1, OSD_VIDEO1_WIDTH/8);
  osdSetComponentConfigA(OSD_VIDEO1,OSD_VIDEO1_CONFIG);

  osdSetComponentSizeA(OSD_BITMAP1, OSD_BITMAP1_WIDTH*2, OSD_BITMAP1_HEIGHT);
  osdSetComponentOffsetA(OSD_BITMAP1, OSD_BITMAP1_ADDRESS);
  osdSetComponentSourceWidthA(OSD_BITMAP1, OSD_BITMAP1_WIDTH/32);

  osdSetComponentSizeA(OSD_BITMAP2, OSD_BITMAP2_WIDTH*2, OSD_BITMAP2_HEIGHT);
  osdSetComponentOffsetA(OSD_BITMAP2, OSD_BITMAP2_ADDRESS);
  osdSetComponentSourceWidthA(OSD_BITMAP2, OSD_BITMAP2_WIDTH/16);

  osdSetComponentSizeA(OSD_CURSOR1, 174*2, 159);

  setTvOutMode(0);

  // tweak lcd parameters (screen flip bug workaround)
  *REG_LCD_VSYNC=9;
}

void initHDD(){
  ataSelectHDDA();
  delay(1000);

  ataPowerUpHDDA();
  ataResetHDDA();
  delay(5000);

  ataReadMBR();

  fat_init();
  fat_mount(getPartition(0)->start);
};

void initDSP(){
  unsigned char *dspcode;
  int len;

  dspcode=&_binary_dspcode_gminisms_dsp_out_start;
  len=&_binary_dspcode_gminisms_dsp_out_end-&_binary_dspcode_gminisms_dsp_out_start;

  debug("initDSP() dspcode=%0.8X len=%d\n",dspcode,len);

  load_dsp_program_mem(dspcode,len);

  *DSP_READY=0;
  *DSP_STOP=0;
  *PSG_ENABLED=0;
  *PSG_MODIFIED=0;
  *PSG_STEREO=0xff;

  dsp_run();

  while(!(*DSP_READY)); // wait for the dsp to finish init
}

void initCodec(){
  aic23Init();
  aic23SetOutputVolume(0,AIC23_CHANNEL_BOTH);
}

void clearOSD(int osd){
  if (osd==OSD_BITMAP1){
    memset((unsigned char *)OSD_BITMAP1_ADDRESS,0,OSD_BITMAP1_WIDTH*2*OSD_BITMAP1_HEIGHT);
    memset((unsigned char *)OSD_BITMAP1_ADDRESS_2,0,OSD_BITMAP1_WIDTH*2*OSD_BITMAP1_HEIGHT);
  }else if (osd==OSD_BITMAP2){
    memset((unsigned char *)OSD_BITMAP2_ADDRESS,0,OSD_BITMAP2_WIDTH*2*OSD_BITMAP2_HEIGHT);
  }
}

void showOSD(int osd){
  osdSetComponentConfigA(OSD_BITMAP1, 0);
  osdSetComponentConfigA(OSD_BITMAP2, 0);
  showGGBorder(false);

  if (osd==OSD_BITMAP1){
    osdSetComponentConfigA(OSD_BITMAP1,OSD_BITMAP1_CONFIG);
  }else if (osd==OSD_BITMAP2){
    osdSetComponentConfigA(OSD_BITMAP2,OSD_BITMAP2_CONFIG);
  }
}

void setTvOutMode(int mode){
  int x,y;

  x=y=0;

  switch(mode){
    case 0:
      videoEnableTvOut(false);
      videoSetTvOutMode(VIDEO_MODE_NTSC | VIDEO_MODE_NONINTERLACED);
      osdSetComponentPositionA(OSD_CURSOR1, LCD_POS_X+16*2, LCD_POS_Y+2);
      osdSetComponentPositionA(OSD_VIDEO1, LCD_POS_X, LCD_POS_Y);
      osdSetComponentPositionA(OSD_BITMAP1, LCD_POS_X-18*2, LCD_POS_Y);
      osdSetComponentPositionA(OSD_BITMAP2, LCD_POS_X, LCD_POS_Y);
      break;
    case 1:
      videoEnableTvOut(true);
      videoSetTvOutMode(VIDEO_MODE_PAL | VIDEO_MODE_NONINTERLACED);
      osdSetComponentPositionA(OSD_CURSOR1, PAL_POS_X+34*2, PAL_POS_Y+10);
      osdSetComponentPositionA(OSD_VIDEO1, PAL_POS_X, PAL_POS_Y);
      osdSetComponentPositionA(OSD_BITMAP1, PAL_POS_X, PAL_POS_Y);
      osdSetComponentPositionA(OSD_BITMAP2, PAL_POS_X, PAL_POS_Y);
      break;
    case 2:
      videoEnableTvOut(true);
      videoSetTvOutMode(VIDEO_MODE_NTSC | VIDEO_MODE_NONINTERLACED);
      osdSetComponentPositionA(OSD_CURSOR1, NTSC_POS_X+34*2, NTSC_POS_Y+10);
      osdSetComponentPositionA(OSD_VIDEO1, NTSC_POS_X, NTSC_POS_Y);
      osdSetComponentPositionA(OSD_BITMAP1, NTSC_POS_X, NTSC_POS_Y);
      osdSetComponentPositionA(OSD_BITMAP2, NTSC_POS_X, NTSC_POS_Y);
      break;
  }

  osdSetComponentOffsetA(OSD_BITMAP1, OSD_BITMAP1_ADDRESS);
}

void loadPicture(unsigned long * data){
  int i;

  for(i=0;i<OSD_VIDEO1_WIDTH*OSD_VIDEO1_HEIGHT;++i){
    *((unsigned long *)(OSD_VIDEO1_ADDRESS+(i<<2)))=data[i] | ((data[i] & 0xff00)<<16);
  }
}

void waitIntroKeyPress(){
  while((buttonsGetStatusA()&BUTTONS_GM400_ANY)!=0) delay(10); // make sure no button is pressed
  while((buttonsGetStatusA()&BUTTONS_GM400_ANY)==0) delay(10); // wait until a button is pressed
  while((buttonsGetStatusA()&BUTTONS_GM400_ANY)!=0) delay(10); // wait until it is released
}

void initSmsEmul(){
  sms.use_fm = false;
  sms.country = TYPE_OVERSEAS;
  sms.save = false;

  bitmap.width  = OSD_BITMAP1_WIDTH;
  bitmap.height = OSD_BITMAP1_HEIGHT;
  bitmap.depth  = 8;
  bitmap.pitch  = OSD_BITMAP1_WIDTH;
  bitmap.data   = (unsigned char*)OSD_BITMAP1_ADDRESS;

  cart.rom=bget(MAX_ROM_SIZE);

  system_init(0);
}

bool loadRom(char *romname){
  int f,cnt;

  f=open(romname,O_RDONLY);
  if (f<0) return false;

  lseek(f,filesize(f)%SMS_BANK_SIZE,SEEK_SET); // skip header if there is one

  cnt=read(f,cart.rom,MAX_ROM_SIZE);

  cart.pages=cnt/SMS_BANK_SIZE;
  cart.type=TYPE_SMS;

  if (strstr(romname,".GG") || strstr(romname,".gg")) cart.type=TYPE_GG;

  close(f);

  debug("rom loaded, %d pages\n",cart.pages);
  return cnt>0;
}

void doEmulLoop(){
  int i,prevTick,frameTickDelta,frameTick;
  int bt;
  int page;
  unsigned int ycbcr,y,cb,cr;

  page=0;
  input.pad[1]=0;
  prevTick=getTickCount();
  do{
    // input handling

    bt=buttonsGetStatusA();

    input.pad[0]=(bt>>4) & 0xf; // directions

    if(swapButtons){
      if(bt&BUTTONS_GM400_SQUARE) input.pad[0]|=INPUT_BUTTON2;
      if(bt&BUTTONS_GM400_CROSS) input.pad[0]|=INPUT_BUTTON1;
    }else{
      if(bt&BUTTONS_GM400_SQUARE) input.pad[0]|=INPUT_BUTTON1;
      if(bt&BUTTONS_GM400_CROSS) input.pad[0]|=INPUT_BUTTON2;
    }

    input.system=0;

    if (bt&BUTTONS_GM400_ON){
      if (cart.type==TYPE_SMS){
        input.system|=INPUT_PAUSE;
      }else{
        input.system|=INPUT_START;
      }
    }

    if (bt&BUTTONS_GM400_MENU1){
      doIngameMenu();
    }

    if (bt&BUTTONS_GM400_MENU2){
      *PSG_ENABLED=0;
      input.system|=INPUT_HARD_RESET;
    }

    if (bt&BUTTONS_GM400_MENU3){
      if (cart.type==TYPE_SMS){
        moveVirtualScreen();
      }else{
        *PSG_ENABLED=0;
        configWriteBool("ExpandGGScreen",!configReadBool("ExpandGGScreen"));
        while((buttonsGetStatusA()&BUTTONS_GM400_ANY)!=0) delay(10); // make sure no button is pressed
        applyConfig();
        *PSG_ENABLED=1;
      }
    }

    // frame skip

    for(i=0;i<frameSkip;++i){
      sms_frame(1);
    }

    // palette update

    if (bitmap.pal.update){
      for(i=0;i<32;++i){
        if(bitmap.pal.dirty[i]){
          ycbcr=graphicsRGB2PackedA(bitmap.pal.color[i][0],bitmap.pal.color[i][1],bitmap.pal.color[i][2]);

          y=(ycbcr>>8) & 0xff;
          cb=(ycbcr>>16) & 0xff;
          cr=ycbcr & 0xff;

          osdSetPalletteA(y,cb,cr,i);
          osdSetPalletteA(y,cb,cr,i+0x20);
          osdSetPalletteA(y,cb,cr,i+0x40);

          bitmap.pal.dirty[i]=false;
        }
      }
      bitmap.pal.update=false;
    }

    // rendering

    sms_frame(0);

    // double buferring

    if (page){
      page=0;
      osdSetComponentOffsetA(OSD_BITMAP1, OSD_BITMAP1_ADDRESS_2+((tvOut)?0:OSD_BITMAP1_WIDTH*vsPosY));
      bitmap.data = (unsigned char*)OSD_BITMAP1_ADDRESS;
    }else{
      page=1;
      osdSetComponentOffsetA(OSD_BITMAP1, OSD_BITMAP1_ADDRESS+((tvOut)?0:OSD_BITMAP1_WIDTH*vsPosY));
      bitmap.data = (unsigned char*)OSD_BITMAP1_ADDRESS_2;
    }

    // frame sync

    frameTick=getTickCount()-prevTick;
//    debug("%d\n",frameTick);
    frameTickDelta=((frameSkip+1)*TICKS_PER_FRAME)-frameTick;
    if (frameTickDelta>0) delay(frameTickDelta);
    if (autoFrameSkip){
      if (frameTickDelta>5) --frameSkip;
      if (frameTickDelta<-10) ++frameSkip;
    };
    prevTick=getTickCount();
  }while(!(bt&BUTTONS_GM400_OFF));
}

void setVirtualScreenPos(){
  if(cart.type==TYPE_SMS || !ggBorder){
    if(!tvOut){
      // change plane position
      osdSetComponentPositionA(OSD_BITMAP1, LCD_POS_X-vsPosX, LCD_POS_Y);
      osdSetComponentOffsetA(OSD_BITMAP1, OSD_BITMAP1_ADDRESS+OSD_BITMAP1_WIDTH*vsPosY);

      //compute emu rendering window
      vp_vstart=vsPosY;
      vp_vend=OSD_BITMAP1_HEIGHT-MAX_VS_POS_Y+vsPosY;

      vp_hstart=vsPosX;
      if ((vp_hstart%16)>0){
        vp_hstart=(vp_hstart>>4)-2;
      }else{
        vp_hstart=(vp_hstart>>4)-1;
      }

      vp_hend=(OSD_BITMAP1_WIDTH<<1)-MAX_VS_POS_X+vsPosX;
      if (vp_hend&0xf){
        vp_hend=(vp_hend>>4)+1;
      }else{
        vp_hend=vp_hend>>4;
      }
    }else{
      vp_vstart = 0;
      vp_vend   = 192;
      vp_hstart = 0;
      vp_hend   = 32;
    }
  }else{
    vp_vstart = 24;
    vp_vend   = 168;
    vp_hstart = 6;
    vp_hend   = 26;
  };
}

void moveVirtualScreen(){
  int bt;

  *PSG_ENABLED=0;

  do{
    bt=buttonsWaitAndRepeat(2500,500,-1);

    if(bt&BUTTONS_GM400_UP) vsPosY-=1;
    if(bt&BUTTONS_GM400_DOWN) vsPosY+=1;
    if(bt&BUTTONS_GM400_LEFT) vsPosX-=2;
    if(bt&BUTTONS_GM400_RIGHT) vsPosX+=2;

    if(vsPosX<0) vsPosX=0;
    if(vsPosY<0) vsPosY=0;

    if(vsPosX>MAX_VS_POS_X) vsPosX=MAX_VS_POS_X;
    if(vsPosY>MAX_VS_POS_Y) vsPosY=MAX_VS_POS_Y;

    setVirtualScreenPos();
  }while(bt&BUTTONS_GM400_MENU3);

  *PSG_ENABLED=1;
}

void showGGBorder(bool show){
  if (cart.type==TYPE_GG && show){
    clearOSD(OSD_BITMAP1);

    osdSetComponentConfigA(OSD_CURSOR1,OSD_CURSOR1_CONFIG);
  }else{
    osdSetComponentConfigA(OSD_CURSOR1,0);
  }
}

void overclockARM(int rate){
  if(rate==0){
    *REG_ARM_CLOCK=0x80E1; // default ARM clock
  }else{
    *REG_ARM_CLOCK=(0x8070+(rate<<4));
  }
}

void setBacklightPower(int power){
  if(power<31){
    *REG_LCD_BACKLIGHT=power<<11;
  }else{
    *REG_LCD_BACKLIGHT=0xFFFF;
  }
}

void doIngameMenu(){
  int res;
  bool loop;

  *PSG_ENABLED=0;

  ingameMenu[1].value=configReadInt("Volume");
  ingameMenu[4].value=configReadInt("Backlight");
  ingameMenu[5].value=configReadInt("TVOut");
  ingameMenu[8].value=configReadBool("ButtonsSwap");
  advancedMenu[1].value=configReadBool("AutoFrameSkip");
  advancedMenu[2].value=configReadInt("FrameSkip");
  advancedMenu[5].value=configReadBool("SpriteLimit");
  advancedMenu[6].value=configReadBool("ExpandGGScreen");
  advancedMenu[7].value=configReadInt("CyclesPerLine");
  advancedMenu[10].value=configReadBool("Overclocking");
  advancedMenu[11].value=configReadInt("OverclockingRate");

  showOSD(OSD_BITMAP2);

  loop=false;
  do{
    res=showMenu("GminiSMS options menu (paused):",ingameMenu,sizeof(ingameMenu)/sizeof(tMenuItem),&osdBmp2,&f6x9,std6x9_,NULL);

    loop=false;
    if (res==4){
      loop=showMenu("GminiSMS advanced options:",advancedMenu,sizeof(advancedMenu)/sizeof(tMenuItem),&osdBmp2,&f6x9,std6x9_,NULL)==1;
    }
  }while(loop);

  showOSD(OSD_BITMAP1);

  configWriteInt("Volume",ingameMenu[1].value);
  configWriteInt("Backlight",ingameMenu[4].value);
  configWriteInt("TVOut",ingameMenu[5].value);
  configWriteBool("ButtonsSwap",ingameMenu[8].value);
  configWriteBool("AutoFrameSkip",advancedMenu[1].value);
  configWriteInt("FrameSkip",advancedMenu[2].value);
  configWriteBool("SpriteLimit",advancedMenu[5].value);
  configWriteBool("ExpandGGScreen",advancedMenu[6].value);
  configWriteInt("CyclesPerLine",advancedMenu[7].value);
  configWriteBool("Overclocking",advancedMenu[10].value);
  configWriteInt("OverclockingRate",advancedMenu[11].value);

  // state saving/loading
  if(res==2) loadSaveState(ingameMenu[11].value,false);
  if(res==3) loadSaveState(ingameMenu[11].value,true);

  applyConfig();

  *PSG_ENABLED=1;
}

void loadDefaultConfig(){
  configClear();

  configWriteBool("AutoFrameSkip",true);
  configWriteInt("FrameSkip",1);

  configWriteBool("ButtonsSwap",true);
  configWriteBool("SpriteLimit",false);
  configWriteBool("ExpandGGScreen",false);
  configWriteInt("CyclesPerLine",256);

  configWriteBool("Overclocking",false);
  configWriteBool("OverclockingRate",0);

  configWriteInt("Volume",75);

  configWriteInt("Backlight",31);
}

void applyConfig(){
  aic23SetOutputVolume(configReadInt("Volume")+27,AIC23_CHANNEL_BOTH);

  setBacklightPower(configReadInt("Backlight"));
  tvOut=configReadInt("TVOut");
  autoFrameSkip=configReadBool("AutoFrameSkip");
  frameSkip=configReadInt("FrameSkip");

  swapButtons=configReadBool("ButtonsSwap");
  vdp.limit=configReadBool("SpriteLimit");
  ggBorder=!configReadBool("ExpandGGScreen");
  sms.cyclesperline=configReadInt("CyclesPerLine");

  if (configReadBool("Overclocking")){ // overclock enabled?
    overclockARM(configReadInt("OverclockingRate"));
  }else{
    overclockARM(0);
  }

  showGGBorder(ggBorder);
  setVirtualScreenPos();

  setTvOutMode(tvOut);
}


void loadSaveState(int slot,bool save){
  char s[255];
  int f;

  if(save){
    sprintf(s,"Saving state, slot %d...",slot);
  }else{
    sprintf(s,"Loading state, slot %d...",slot);
  }

  clearOSD(OSD_BITMAP2);
  showOSD(OSD_BITMAP2);
  graphicsStringA(&osdBmp2, 0, 0, &f8x13, std8x13_, 8, 0,s);

  prepareHDDAccess();

  strcpy(s,romname);
  *strrchr(s,'.')='\0';
  sprintf(s,"%s.st%d",s,slot-1);

  if(save){
    f=creat(s,O_CREAT);
    if (f>=0){
      system_save_state(f);
      close(f);
    }else{
      graphicsStringA(&osdBmp2, 0, 15, &f8x13, std8x13_, 8, 0,"Can't save!");
    }
  }else{
    f=open(s,O_RDONLY);
    if (f>=0){
      system_load_state(f);
      close(f);
    }else{
      graphicsStringA(&osdBmp2, 0, 15, &f8x13, std8x13_, 8, 0,"Not found!");
    }
  }

  endHDDAccess();

  showOSD(OSD_BITMAP1);
}

void loadSaveSram(bool save){
  char s[255];
  int f;

  if(save){
    strcpy(s,"Saving SRAM...");
  }else{
    strcpy(s,"Loading SRAM...");
  }

  clearOSD(OSD_BITMAP2);
  showOSD(OSD_BITMAP2);
  graphicsStringA(&osdBmp2, 0, 0, &f8x13, std8x13_, 8, 0,s);

  strcpy(s,romname);
  *strrchr(s,'.')='\0';
  strcat(s,".sav");

  if(save){
    f=creat(s,O_CREAT);
    if (f>=0){
      write(f,sms_sram,sizeof(sms_sram));
      close(f);
    }
  }else{
    f=open(s,O_RDONLY);
    if (f>=0){
      read(f,sms_sram,sizeof(sms_sram));
      close(f);
    }
  }
}

void prepareHDDAccess(){
  overclockARM(0); // safer not to overclock during HDD access

  ataPowerUpHDDA();
}

void endHDDAccess(){
  ataSleepCmdA();
  ataPowerDownHDDA();

  overclockARM(configReadInt("OverclockingRate"));

  while((buttonsGetStatusA()&BUTTONS_GM400_ANY)!=0) delay(100); // workaround button bug
}

void drawProgress(int offset,int length,int mode){}
