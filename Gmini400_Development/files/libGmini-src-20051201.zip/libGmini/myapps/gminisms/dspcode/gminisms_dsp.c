#include <stdio.h>
#include <string.h>

#include <csl.h>
#include <csl_mcbsp.h>
#include <csl_irq.h>

#include "sn76496.h"

#define DSP_READY 		((volatile unsigned short *)0x80)
#define DSP_STOP 		((volatile unsigned short *)0x81)
#define PSG_ENABLED 	((volatile unsigned short *)0x82)
#define PSG_DATA 		((volatile unsigned short *)0x83)
#define PSG_MODIFIED 	((volatile unsigned short *)0x84)
#define PSG_STEREO  	((volatile unsigned short *)0x85)

#define BUFFER_SIZE 1

static short buf1[BUFFER_SIZE];
static short buf2[BUFFER_SIZE];
static short* buffer[2]={buf1,buf2};

static MCBSP_Config DataPortCfg= {
  0x0000,0x0200, /* SPCR : free running mode */
  0x00A0,0x0001, /* RCR  : 32 bit receive data length */  
  0x00A0,0x0000, /* XCR  : 32 bit transmit data length */            
  0x0000,0x3000,  
  0x0000,0x0000, /* MCR  : single channel */
  0x000E,        /* PCR  : FSX, FSR active low, external FS/CLK source */
  0x0000,
  0x0000,
  0x0000,
  0x0000
};     


MCBSP_Handle openAIC23DataPort();

void main(){
 	MCBSP_Handle dataPort;
	int i;

	CSL_init();

	dataPort=openAIC23DataPort();

	if (dataPort==INV){
		return;
	}

	SN76496_init(3579545,44100); // 3.58Mhz / 44.1Khz sample rate

	*DSP_READY=1;
		
	do{
		if(*PSG_MODIFIED){
			SN76496Write(*PSG_DATA);
			*PSG_MODIFIED=0;
		}

		SN76496Update(buffer,BUFFER_SIZE,*PSG_STEREO);

		for(i=0;i<BUFFER_SIZE;++i){
			while(!MCBSP_xrdy(dataPort));
    		MCBSP_write32(dataPort,buffer[0][i]*0x20000|(buffer[1][i])*2);
		}

		while(!(*PSG_ENABLED));

	}while(!(*DSP_STOP));
}

MCBSP_Handle openAIC23DataPort(){
 	MCBSP_Handle port;

	port = MCBSP_open(MCBSP_PORT0, MCBSP_OPEN_RESET);
	if (port==INV){
		return INV;
	}

	MCBSP_config(port,&DataPortCfg);

	MCBSP_start(port,MCBSP_XMIT_START,0);
	
	return port;
}
