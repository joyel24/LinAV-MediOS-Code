/*

 All files in this archive are subject to the GNU General Public License.
 See the file COPYING in the source tree root for full license agreement.
 This software is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY
 KIND, either express of implied.

 Menu handling function

 Date:     28/09/2005
 Author:   GliGli

*/

#include <menu.h>

#define MENU_BACK_COLOR      0
#define MENU_TITLE_COLOR     1
#define MENU_NAME_COLOR      2
#define MENU_NAMESEL_COLOR   3
#define MENU_VALUE_COLOR     4
#define MENU_VALUESEL_COLOR  5
#define MENU_DUMMY_COLOR     6

int default_menu_colors[] = {COL_BLACK, COL_GREEN, COL_WHITE, COL_BLUE, COL_WHITE, COL_DARKGREY, COL_DARKGREY};

int showMenu(char * title,tMenuItem * items,int itemcount,struct graphicsBuffer *osd,struct graphicsBuffer *fnt,char ** fntdat,int colors[]) {
  int i,y,selidx,selinc,valinc,val,cx,bgcolor,fgcolor,result,bt;
  bool quit;

  char str[10];

  int ** oldpal;
  int pal[2];

  int intvaluebarx=osd->width/2;
  int intvaluebarwidth=osd->width/3;
  int intvaluex=14*osd->width/16;

  int boolvaluex1=4*osd->width/8;
  int boolvaluex2=6*osd->width/8;

  if(!colors) colors=default_menu_colors;

  pal[0]=colors[MENU_BACK_COLOR];
  pal[1]=colors[MENU_NAME_COLOR];

  // replace the font pallette with the local pallette
  oldpal=fnt->pallette16;
  fnt->pallette16=(int**)pal;

  graphicsBoxfA(osd, 0, 0, osd->width, osd->height, colors[MENU_BACK_COLOR]);

  // title
  pal[1]=colors[MENU_TITLE_COLOR];
  graphicsStringA(osd, 0, 0, fnt, fntdat, fnt->width, 0,title);

  selidx=0;
  while(items[selidx].type==ITEMTYPE_DUMMY) ++selidx; //go to first non dummy item

  quit=false;
  result=0;
  do{
    // drawing
    y=fnt->height;
    for(i=0;i<itemcount;++i){
      // name
      bgcolor=colors[MENU_BACK_COLOR];
      if (i==selidx) bgcolor=colors[MENU_NAMESEL_COLOR];

      fgcolor=colors[MENU_NAME_COLOR];
      if (items[i].type==ITEMTYPE_DUMMY) fgcolor=colors[MENU_DUMMY_COLOR];

      pal[0]=bgcolor;
      pal[1]=fgcolor;

      graphicsStringA(osd, 0, y, fnt, fntdat, fnt->width, 0,items[i].name);

      // values
      bgcolor=colors[MENU_VALUESEL_COLOR];
      if (i==selidx) bgcolor=colors[MENU_NAMESEL_COLOR];

      pal[0]=colors[MENU_BACK_COLOR];
      pal[1]=colors[MENU_VALUE_COLOR];

      switch (items[i].type) {
        case ITEMTYPE_INTEGER:
          // clear
          graphicsBoxfA(osd, intvaluebarx, y, osd->width/2, fnt->height, colors[MENU_BACK_COLOR]);
          // bar
          graphicsBoxfA(osd, intvaluebarx, y+fnt->height/3, intvaluebarwidth, fnt->height/3, colors[MENU_VALUE_COLOR]);
          // cursor
          cx=intvaluebarx + (items[i].value-items[i].min) * (intvaluebarwidth-fnt->width) / (items[i].max-items[i].min);
          graphicsBoxfA(osd, cx, y, fnt->width, fnt->height, bgcolor);
          // value
          sprintf(str,"%d",items[i].value);
          graphicsStringA(osd, intvaluex, y, fnt, fntdat, fnt->width, 0,str);
          break;
        case ITEMTYPE_BOOLEAN:
          // enabled
          if(items[i].value!=0) pal[0]=bgcolor; else pal[0]=colors[MENU_BACK_COLOR];
          //debug("",pal[0]); // HACK: workaround GCC optimisation bug
          graphicsStringA(osd, boolvaluex1, y, fnt, fntdat, fnt->width, 0,"Enabled");
          // disabled
          if(items[i].value!=0) pal[0]=colors[MENU_BACK_COLOR]; else pal[0]=bgcolor;
          //debug("",pal[0]); // HACK: workaround GCC optimisation bug
          graphicsStringA(osd, boolvaluex2, y, fnt, fntdat, fnt->width, 0,"Disabled");
          break;
      }

      y+=fnt->height;
    }

    // buttons handling
    selinc=0;
    valinc=0;
    bt=buttonsWaitAndRepeat(5000,1000,20000);

    if (bt & BUTTONS_GM400_OFF){
      quit=true;
      break;
    }

    if (bt & BUTTONS_GM400_UP) selinc=-1;
    if (bt & BUTTONS_GM400_DOWN) selinc=1;

    // make sure selection does not go off limits & skip dummy items
    do{
      selidx+=selinc;
      selidx=(selidx<0)?itemcount-1:selidx;
      selidx=(selidx>=itemcount)?0:selidx;
    }while(items[selidx].type==ITEMTYPE_DUMMY);

    if (bt & BUTTONS_GM400_LEFT || bt & BUTTONS_GM400_CROSS) valinc=-1;
    if (bt & BUTTONS_GM400_RIGHT || bt & BUTTONS_GM400_SQUARE) valinc=1;

    // handle value change
    if (valinc){
      switch (items[selidx].type) {
        case ITEMTYPE_INTEGER:
          val=items[selidx].value;
          val+=valinc;
          val=(val<items[selidx].min)?items[selidx].min:val;
          val=(val>items[selidx].max)?items[selidx].max:val;
          items[selidx].value=val;
          break;
        case ITEMTYPE_BOOLEAN:
          items[selidx].value=false;
          if(valinc<0) items[selidx].value=true;
          break;
        case ITEMTYPE_ACTION:
          result=items[selidx].value;
          quit=true;
          break;
      }
    }

  }while (!quit);

  // restore the original font pallette
  fnt->pallette16=oldpal;

  // make sure no button is pressed before quitting
  while((buttonsGetStatusA()&BUTTONS_GM400_ANY)!=0) delay(100);

  return result;
}
