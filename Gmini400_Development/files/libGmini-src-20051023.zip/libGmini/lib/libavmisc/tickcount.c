/*

 All files in this archive are subject to the GNU General Public License.
 See the file COPYING in the source tree root for full license agreement.
 This software is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY
 KIND, either express of implied.

 Time related functions

 Date:     27/09/2005
 Author:   GliGli

*/

#include <tickcount.h>

int numSeconds=0;
int prevTickCount=0;

void initTickCount(){
  timersConfigA(0,TIMERS_TMMD_FREERUN,TIMERS_TMCLK_EXT,675,40000); // 40000 ticks=1 second
  numSeconds=0;
  prevTickCount=timersGetValueA(0);
}

unsigned int getTickCount(){
  int tc;

  tc=timersGetValueA(0);

  //the timer overflowed -> at least 1 second passed
  //TODO: should be handled by an interrupt
  if(prevTickCount>tc){
    ++numSeconds;
  }

  prevTickCount=tc;
  return ((numSeconds*TICKS_PER_SECOND)+(tc/4));
}

void delay(int time){
  int tc;

  tc=getTickCount();
  while((getTickCount()-tc)<time) /* nothing */;
}

