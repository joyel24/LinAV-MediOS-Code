/*
*   kernel/driver/i2c.c
*
*   AMOS project
*   Copyright (c) 2005 by Christophe THOMAS (oxygen77 at free.fr)
*
* All files in this archive are subject to the GNU General Public License.
* See the file COPYING in the source tree root for full license agreement.
* This software is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY
* KIND, either express of implied.
*/

#include "include/io.h"

//TODO: target dependant
#define GIO_DIRECTION 0x30580
#define GIO_BITSET 0x3058c
#define GIO_BITCLEAR 0x30592

#define SDA_BIT 8
#define SCL_BIT 9
//TODO: target dependant end


#define DELAY_1              { int _x; for(_x=0;_x<10;_x++); };
#define DELAY_2              { int _x; for(_x=0;_x<10;_x++); };

#define SDA_MASK           (1<<SDA_BIT)
#define SDA_N_MASK         (~SDA_MASK)

#define SDA_HI             outw(SDA_MASK,GIO_BITSET);
#define SDA_LO             outw(SDA_MASK,GIO_BITCLEAR);
#define SDA_IN             outw(inw(GIO_DIRECTION) | SDA_MASK,GIO_DIRECTION);
#define SDA_OUT            outw(inw(GIO_DIRECTION) & SDA_N_MASK,GIO_DIRECTION);
#define SDA                inw(GIO_BITSET)&SDA_MASK

#define SCL_MASK           (1<<SCL_BIT)
#define SCL_N_MASK         (~SCL_MASK)

#define SCL_HI             outw(SCL_MASK,GIO_BITSET);
#define SCL_LO             outw(SCL_MASK,GIO_BITCLEAR);
#define SCL_IN             outw(inw(GIO_DIRECTION) | SCL_MASK,GIO_DIRECTION);
#define SCL_OUT            outw(inw(GIO_DIRECTION) & SCL_N_MASK,GIO_DIRECTION);
#define SCL                inw(GIO_BITSET)&SCL_MASK

#define ENA_INT
//sti();
#define DIS_INT
//cli();

#define DA_1               DIS_INT SDA_IN ENA_INT
#define CL_1               DIS_INT SCL_IN ENA_INT 
#define DA_0               DIS_INT SDA_LO SDA_OUT ENA_INT
#define CL_0               DIS_INT SCL_LO SCL_OUT ENA_INT

#define i2cIniXfer()     { int _val; DELAY_1 CL_1 DELAY_1 DA_1 DELAY_1 \
                                _val=inw(GIO_BITSET);\
                                if(!(_val & SCL_MASK) || !(_val & SDA_MASK)) return -1; \
                           }

#define WAIT_I2C           while(!SCL) /*nothing*/;

void i2cStart(void)
{
    DELAY_1
    CL_1
    DELAY_1
    DA_0
    DELAY_1
    CL_0
    DELAY_1
}

void i2cStop(void)
{
    CL_0
    DELAY_1
    DA_0
    DELAY_1
    CL_1
    DELAY_1
    DA_1
    DELAY_1
}

void i2cAck(void)
{
    CL_0
    DELAY_1
    DA_0
    DELAY_1
    CL_1
    DELAY_1
    while(!SCL) /*nothing*/;
    DELAY_1
    CL_0
    DELAY_1
    DA_1
    DELAY_1
}

void i2cAckEnd(void)
{
    CL_0
    DELAY_1
    DA_1
    DELAY_1
    CL_1
    DELAY_1
    WAIT_I2C
    DELAY_1
    CL_0
    DELAY_1
}

int i2cGetAck(void)
{
    int ret=0;
    
    CL_0
    DELAY_1
    DA_1
    DELAY_1
    CL_1
    DELAY_1
    WAIT_I2C
    DELAY_1
    if(SDA)
        ret=1;
    DELAY_1
    CL_0
    DELAY_1
    return ret;
}

char i2cInb(void)
{
    char i;
    char ret=0;
    for(i=0x80;i;i=i>>1)
    {
        CL_0
        DELAY_1
        CL_1
        DELAY_1
        WAIT_I2C
        if(SDA)
            ret |= i; 
         DELAY_1     
    }
    CL_0
    DELAY_1    
    return ret;
}

int i2cOutb(char data)
{
    char i;    
    for(i=0x80;i;i=i>>1)
    {
        CL_0
        DELAY_1
        if(i&data)
        {
            DA_1
        }
        else
        {
            DA_0
        }
        DELAY_1
        CL_1
        DELAY_1        
    }
    CL_0
    DELAY_1
    return i2cGetAck();
}

int i2cRead(int device, int address, void * buffer, int count)
{
    int i;
    char * buff=(char*) buffer;

    i2cIniXfer();
    
    i2cStart();

    if(i2cOutb(((device<<24)>>25)<<1) != 0)
        return -2;

    if(i2cOutb((address<<24)>>24) != 0)
        return -3;

    i2cStart();

    if(i2cOutb(((device<<24)>>24)|1) != 0)
        return -4;
    
    for(i=0;i<count-1;i++)
    {
        buff[i]=i2cInb();
        i2cAck();
    }
    
    buff[i]=i2cInb();

    i2cAckEnd();
    i2cStop();
    return 0;
}

int i2cWrite(int device, int address, void * buffer, int count)
{
    int i;
    char * buff=(char*) buffer;

    i2cIniXfer();
    
    i2cStart();

    if(i2cOutb(((device<<24)>>25)<<1) != 0)
        return -1;

    if(i2cOutb((address<<24)>>24) != 0)
        return -2;

    for(i=0;i<count;i++)
        if(i2cOutb(buff[i])!=0)
            return -3;

    i2cStop();
    return 0;
}

int i2cWriteRaw(int device, void * buffer, int count)
{
    int i;
    char * buff=(char*) buffer;

    i2cIniXfer();
    
    i2cStart();

    if(i2cOutb(((device<<24)>>25)<<1) != 0)
        return -1;

    for(i=0;i<count;i++)
        if(i2cOutb(buff[i])==0)
            break;

    i2cStop();
    return 0;
}
