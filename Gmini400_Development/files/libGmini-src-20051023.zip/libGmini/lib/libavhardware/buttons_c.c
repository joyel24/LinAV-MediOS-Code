/*

 All files in this archive are subject to the GNU General Public License.
 See the file COPYING in the source tree root for full license agreement.
 This software is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY
 KIND, either express of implied.

 Buttons functions

 Date:     27/09/2005
 Author:   GliGli

*/

#include <buttons.h>

int prevBt=0;
bool rateMode=false;
int rateStart=0;

int buttonsWaitAndRepeat(int delaywait,int ratewait, int rateincrease){
  int bt,baset,deltat;

  baset=getTickCount();

  if(rateincrease && rateincrease!=-1 && rateMode){
    ratewait/=1+(baset-rateStart)/rateincrease;
  }

  do{
    bt=buttonsGetStatusA();

    deltat=getTickCount()-baset;
  }while((prevBt==bt) && ((deltat<delaywait && !rateMode) || (deltat<ratewait && rateMode)));

  if (deltat<ratewait){
    rateMode=false;
  }

  if (deltat>=delaywait){
    rateMode=true;
    rateStart=getTickCount();
  }

  prevBt=bt;

  return bt;
}