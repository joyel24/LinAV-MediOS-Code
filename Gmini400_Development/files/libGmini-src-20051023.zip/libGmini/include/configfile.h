/*

 All files in this archive are subject to the GNU General Public License.
 See the file COPYING in the source tree root for full license agreement.
 This software is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY
 KIND, either express of implied.

 Configuration file reader/writer

 Date:     08/10/2005
 Author:   GliGli

*/

#ifndef __CONFIGFILE_H
#define __CONFIGFILE_H

#include <file.h>
#include <string.h>
#include <stdbool.h>

#define MAX_CONFIGFILE_LENGTH 4096

void configClear();

int configLoad(const char * fn);
int configSave(const char * fn);

void configTrim(char *s);

bool configReadString(const char * name,char * value);
int configReadInt(const char * name);
bool configReadBool(const char * name);

bool configRemoveValue(const char * name);

void configWriteString(const char * name,const char * value);
void configWriteInt(const char * name,int value);
void configWriteBool(const char * name,bool value);

#endif /*__CONFIGFILE_H*/
