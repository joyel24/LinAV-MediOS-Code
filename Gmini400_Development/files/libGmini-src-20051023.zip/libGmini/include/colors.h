/*

 All files in this archive are subject to the GNU General Public License.
 See the file COPYING in the source tree root for full license agreement.
 This software is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY
 KIND, either express of implied.

 OSD ROM palette named colors

 Date:     20/09/2005
 Author:   GliGli

*/
#ifndef __COLORS_H
#define __COLORS_H

#define COL_WHITE     0xffff
#define COL_CYAN      0xfefe
#define COL_MAGENTA   0xfdfd
#define COL_BLUE      0xfcfc
#define COL_YELLOW    0xfbfb
#define COL_GREEN     0xfafa
#define COL_RED       0xf9f9
#define COL_DARKGREY  0xf8f8
#define COL_GREY      0xf7f7
#define COL_LIGHTGREY 0xf6f6
#define COL_BLACK     0xf5f5


#endif  /* __FILEBROWSER_H */
