/*

 All files in this archive are subject to the GNU General Public License.
 See the file COPYING in the source tree root for full license agreement.
 This software is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY
 KIND, either express of implied.

 Menu handling function

 Date:     28/09/2005
 Author:   GliGli

*/

#ifndef __MENU_H
#define __MENU_H

#include <stdbool.h>
#include <colors.h>
#include <buttons.h>
#include <graphics.h>
#include <string.h>
#include <tickcount.h>

#define ITEMTYPE_INTEGER 0
#define ITEMTYPE_BOOLEAN 1
#define ITEMTYPE_ACTION  2
#define ITEMTYPE_DUMMY   3

typedef struct {
  char name[50];
  char type;
  int value;
  int min;
  int max;
}tMenuItem;

int showMenu(char * title,tMenuItem * items,int itemcount,struct graphicsBuffer *osd,struct graphicsBuffer *fnt,char ** fntdat,int colors[]);

#endif  /* __MENU_H */
