/* libavos.h
   By William Bland (aka awksedgrep)
   Copyright 2004, the Avos project.

   This file is free software; we give unlimited permission to copy
   and/or distribute it, with or without modifications, as long as this
   notice is preserved.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY, to the extent permitted by law; without
   even the implied warranty of MERCHANTABILITY or FITNESS FOR A
   PARTICULAR PURPOSE.
*/
#ifndef u32_defined
#define u32_defined yes
typedef unsigned long u32;
#endif

#define RTC_DEVICE                        0xd0
#define TSC_DEVICE                        0x90
#define MAS_DEVICE                        0x3c
#define AIC_DEVICE                        0x36

#define I2C_WRITE_DEVICE(val)                   (val & ~0x01)
#define I2C_READ_DEVICE(val)                    (val | 0x01)

extern int i2cWrite(int device, int address, void * buffer, int count);
extern int i2cWriteRaw(int device, void * buffer, int count);
extern int i2cRead(int device, int address, void * buffer, int count);
extern int i2cOutb(char data);
extern char i2cInb();
extern int i2cGetAck();
extern void i2cStop();
extern void i2cStart();
extern void i2cAck();
extern void i2cAckEnd();
