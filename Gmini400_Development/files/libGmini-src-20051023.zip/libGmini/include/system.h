/* libavos.h
   By William Bland (aka awksedgrep)
   Copyright 2004, the Avos project.

   This file is free software; we give unlimited permission to copy
   and/or distribute it, with or without modifications, as long as this
   notice is preserved.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY, to the extent permitted by law; without
   even the implied warranty of MERCHANTABILITY or FITNESS FOR A
   PARTICULAR PURPOSE.
*/
#ifndef __SYSTEM_H
#define __SYSTEM_H

#ifndef u32_defined
#define u32_defined yes
typedef unsigned long u32;
#endif

#define REG (volatile unsigned short *)

extern void systemRelocateMe();
extern void systemRelocateMeA();

extern void mvStackA();
extern void mvStack();

#endif /*__SYSTEM_H*/
