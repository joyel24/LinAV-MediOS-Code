/*

 All files in this archive are subject to the GNU General Public License.
 See the file COPYING in the source tree root for full license agreement.
 This software is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY
 KIND, either express of implied.

 Browse for file dialog

 Date:     20/09/2005
 Author:   GliGli

*/
#ifndef __FILEBROWSER_H
#define __FILEBROWSER_H

#include <stdlib.h>
#include <stdbool.h>
#include <colors.h>
#include <dir.h>
#include <buttons.h>
#include <graphics.h>
#include <string.h>
#include <tickcount.h>
#include <debug.h>

#define MAX_FILES_IN_DIR 1000

typedef struct {
  char name[255];
  bool isdir;
}tDirItem;

bool browseForFile(char * fn,struct graphicsBuffer *osd,struct graphicsBuffer *fnt,char ** fntdat,int colors[]);
void appendDirToPath(char * path,char * dir);

#endif  /* __FILEBROWSER_H */
