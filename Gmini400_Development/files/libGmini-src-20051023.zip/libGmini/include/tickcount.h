/*

 All files in this archive are subject to the GNU General Public License.
 See the file COPYING in the source tree root for full license agreement.
 This software is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY
 KIND, either express of implied.

 Time related functions

 Date:     27/09/2005
 Author:   GliGli

*/
#ifndef __TICKCOUNT_H
#define __TICKCOUNT_H

#include <timers.h>

#define TICKS_PER_SECOND 10000
#define TICKS_PER_MINUTE TICKS_PER_SECOND*60

void initTickCount();
unsigned int getTickCount();
void delay(int time);

#endif /* __TICKCOUNT_H */
