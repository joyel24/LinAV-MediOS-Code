void main(){

*(volatile int *)0x0080=0x1234;

*(volatile int *)0x0040=0x5678;

*(volatile int *)0x0000=0x9abc;

for(;;);


}
