/*

 All files in this archive are subject to the GNU General Public License.
 See the file COPYING in the source tree root for full license agreement.
 This software is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY
 KIND, either express of implied.

 Menu test program

 Date:     11/10/2005
 Author:   GliGli

*/

#include "string.h"
#include <ata.h>
#include <fat.h>
#include <file.h>
#include <system.h>
#include <graphics.h>
#include <osdDSC25.h>
#include <buttons.h>
#include <fonts.h>
#include <debug.h>
#include <usb.h>
#include <timers.h>

#include <menu.h>
#include <tickcount.h>

#define LCD_WIDTH 220
#define LCD_HEIGHT 176

#define OSD_BITMAP1_WIDTH 240
#define OSD_BITMAP1_HEIGHT 176

#define OSD_BITMAP1_ADDRESS 0x018d1500

static struct graphicsBuffer osdBmp1;

static int pal[2] = {0x0000, 0xffff};

static tMenuItem menuitems[]={{"Test int",ITEMTYPE_INTEGER,4,0,10},
                              {"Test int2",ITEMTYPE_INTEGER,2,2,10},
                              {"Test int3",ITEMTYPE_INTEGER,10,0,10},
                              {"Test dummy",ITEMTYPE_DUMMY,0,0,0},
                              {"Test bool",ITEMTYPE_BOOLEAN,false,0,0},
                              {"Test bool2",ITEMTYPE_BOOLEAN,true,0,0},
                              {"",ITEMTYPE_DUMMY,0,0,0},
                              {"Test action",ITEMTYPE_ACTION,1,0,0}};

//static struct graphicsBuffer f5x7  = {0, 1, 5, 7, 1, 0, -1, 0, 0, 0, 0, (int**) &pal, (int**) NULL};
static struct graphicsBuffer f6x9  = {0, 1, 6, 9, 1, 0, -1, 0, 0, 0, 0, (int**) &pal, (int**) NULL};
//static struct graphicsBuffer f8x13 = {0, 1, 8, 13, 1, 0, -1, 0, 0, 0, 0, (int**) &pal, (int**) NULL};

//static unsigned long * screenDirect = (unsigned long*) 0x018d1500;

void initDisplay();
void initHDD();

int main(){
  initTickCount();
  initDisplay();

  graphicsBoxfA(&osdBmp1, 0, 0, OSD_BITMAP1_WIDTH, OSD_BITMAP1_HEIGHT, 0);

  showMenu("Test menu:",menuitems,sizeof(menuitems)/sizeof(tMenuItem),&osdBmp1,&f6x9,std6x9_,NULL);

  return 0;
}

void initDisplay(){

  osdSetComponentConfigA(OSD_VIDEO1, 0);
  osdSetComponentConfigA(OSD_VIDEO1, 0);
  osdSetComponentConfigA(OSD_BITMAP1, 0);
  osdSetComponentConfigA(OSD_BITMAP2, 0);
  osdSetComponentConfigA(OSD_CURSOR1, 0);
  osdSetComponentConfigA(OSD_CURSOR2, 0);

  osdBmp1.offset = OSD_BITMAP1_ADDRESS;
  osdBmp1.bytesPerLine = OSD_BITMAP1_WIDTH*2;
  osdBmp1.width = LCD_WIDTH;
  osdBmp1.height = OSD_BITMAP1_HEIGHT;
  osdBmp1.bitsPerPixelShift = 4;
  osdBmp1.bitsPerPixel = 16;

  graphicsBoxfA(&osdBmp1,0,0,OSD_BITMAP1_WIDTH,OSD_BITMAP1_HEIGHT,0x0000);

  osdSetMainConfigA(1);
  osdSetBacklightA(1);

  osdSetComponentSizeA(OSD_BITMAP1, OSD_BITMAP1_WIDTH*2, OSD_BITMAP1_HEIGHT);
  osdSetComponentPositionA(OSD_BITMAP1, 0xfc, 0x18);
  osdSetComponentOffsetA(OSD_BITMAP1, OSD_BITMAP1_ADDRESS);
  osdSetComponentSourceWidthA(OSD_BITMAP1, 0xf);
  osdSetComponentConfigA(OSD_BITMAP1, OSD_COMPONENT_ENABLE
                                   | OSD_BITMAP_8BIT
                                   | OSD_BITMAP_0TRANS
                                   );


}
