/*

 All files in this archive are subject to the GNU General Public License.
 See the file COPYING in the source tree root for full license agreement.
 This software is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY
 KIND, either express of implied.

 SMS/GG emulator (port of SMS Plus by Charles Mac Donald)

 Date:     11/10/2005
 Author:   GliGli

*/

#include "string.h"
#include <ata.h>
#include <fat.h>
#include <file.h>
#include <system.h>
#include <graphics.h>
#include <osdDSC25.h>
#include <buttons.h>
#include <fonts.h>
#include <debug.h>
#include <usb.h>
#include <timers.h>
#include <uart.h>

#include <configfile.h>
#include <filebrowser.h>
#include <menu.h>
#include <colors.h>

#include "shared.h"

#define REG_ARM_CLOCK (REG 0x30880)

#define REG_LCD_VSYNC (REG 0x3082C)

#define LCD_WIDTH 220
#define LCD_HEIGHT 176

#define OSD_BITMAP1_WIDTH 256
#define OSD_BITMAP1_HEIGHT 192

#define OSD_BITMAP2_WIDTH 240
#define OSD_BITMAP2_HEIGHT 176

#define OSD_BITMAP1_CONFIG  OSD_COMPONENT_ENABLE | OSD_BITMAP_8BIT | OSD_BITMAP_MERGEBACK | OSD_BITMAP_A7 | OSD_BITMAP_ZX1 | OSD_BITMAP_RAMCLUT
#define OSD_BITMAP2_CONFIG  OSD_COMPONENT_ENABLE | OSD_BITMAP_8BIT | OSD_BITMAP_0TRANS
#define OSD_CURSOR1_CONFIG  OSD_COMPONENT_ENABLE | 7<<OSD_CURSOR1_BORDERHEIGHT_SHIFT | 7<<OSD_CURSOR1_BORDERWIDTH_SHIFT | OSD_CURSOR1_RAMCLUT | 0<<OSD_CURSOR1_COLOR_SHIFT

#define OSD_BITMAP1_ADDRESS   0x018b0000
#define OSD_BITMAP1_ADDRESS_2 0x018c0000
#define OSD_BITMAP2_ADDRESS   0x018d1500

#define LCD_POS_X 0xfc
#define LCD_POS_Y 0

#define MAX_VS_POS_X 72
#define MAX_VS_POS_Y 16

#define MAX_ROM_SIZE 1024*1024
#define SMS_BANK_SIZE 16384

#define TICKS_PER_FRAME 167

#define CONFIG_FILE "/System/GminiSMS.cfg"

char _real_iram_start;
char _iram_start;
char _iram_end;

static struct graphicsBuffer osdBmp1;
static struct graphicsBuffer osdBmp2;

static int pal[2] = {COL_BLACK, COL_WHITE};

static struct graphicsBuffer f5x7  = {0, 1, 5, 7, 1, 0, -1, 0, 0, 0, 0, (int**) &pal, (int**) NULL};
static struct graphicsBuffer f6x9  = {0, 1, 6, 9, 1, 0, -1, 0, 0, 0, 0, (int**) &pal, (int**) NULL};
static struct graphicsBuffer f8x13 = {0, 1, 8, 13, 1, 0, -1, 0, 0, 0, 0, (int**) &pal, (int**) NULL};

int vsPosX=0;
int vsPosY=0;

bool autoFrameSkip;
int  frameSkip;
bool ggBorder;
bool swapButtons;

tMenuItem ingameMenu[]={
  {"",ITEMTYPE_DUMMY,0,0,0},
  {"Frame skip options:",ITEMTYPE_DUMMY,0,0,0},
  {"Auto frame skip",ITEMTYPE_BOOLEAN,0,0,0},
  {"Frame skip",ITEMTYPE_INTEGER,0,0,10},
  {"Emulation options:",ITEMTYPE_DUMMY,0,0,0},
  {"Swap buttons",ITEMTYPE_BOOLEAN,0,0,0},
  {"Sprite limit",ITEMTYPE_BOOLEAN,0,0,0},
  {"Expand GG screen",ITEMTYPE_BOOLEAN,0,0,0},
  {"CPU cycles / line",ITEMTYPE_INTEGER,0,0,512},
  {"Gmini overclock (at your own risk!):",ITEMTYPE_DUMMY,0,0,0},
  {"Enable overclock",ITEMTYPE_BOOLEAN,0,0,0},
  {"Overclock rate",ITEMTYPE_INTEGER,0,0,5},
  {"State saving:",ITEMTYPE_DUMMY,0,0,0},
  {"Slot",ITEMTYPE_INTEGER,1,1,10},
  {"Load state",ITEMTYPE_ACTION,2,0,0},
  {"Save state",ITEMTYPE_ACTION,3,0,0},
  {"",ITEMTYPE_DUMMY,0,0,0},
  {"Return to game",ITEMTYPE_ACTION,1,0,0}
};

static char romname[256];

void copyIramContent();

void initDisplay();
void showOSD(int osd);
void initHDD();

void drawIntro();
void waitIntroKeyPress();

void initSmsEmul();
bool loadRom(char *romname);
void doEmulLoop();

void setVirtualScreenPos();
void moveVirtualScreen();

void showGGBorder(bool show);

void doIngameMenu();
void overclockARM(int rate);

void loadDefaultConfig();
void applyConfig();

void loadSaveState(int slot,bool save);
void loadSaveSram(bool save);

void prepareHDDAccess();
void endHDDAccess();

int main(){
  initDisplay();
  drawIntro();
  showOSD(OSD_BITMAP2);

  // init
  initTickCount();
  copyIramContent();
  bpool(0x1000000,0x600000);
  initHDD();
  initSmsEmul();

  loadDefaultConfig();
  configLoad(CONFIG_FILE);

  waitIntroKeyPress();

  for(;;){
    showOSD(OSD_BITMAP2);

    if (!browseForFile(romname,&osdBmp2,&f6x9,std6x9_,NULL)) break;

    if (!loadRom(romname)) continue;

    system_reset();
    loadSaveSram(false);

    graphicsBoxfA(&osdBmp1,0,0,OSD_BITMAP2_WIDTH,OSD_BITMAP2_HEIGHT,0x00);
    showOSD(OSD_BITMAP1);

    endHDDAccess();

    applyConfig();

    // center virtual screen
    vsPosX=MAX_VS_POS_X/2;
    vsPosY=MAX_VS_POS_Y/2;
    setVirtualScreenPos();

    doEmulLoop();

    prepareHDDAccess();

    if(sms.save) loadSaveSram(true);
  }

  overclockARM(0); // restore original ARM clock

  configSave(CONFIG_FILE);

  graphicsBoxfA(&osdBmp2,0,0,OSD_BITMAP1_WIDTH,OSD_BITMAP1_HEIGHT,COL_BLACK);
  graphicsStringA(&osdBmp2, 0, 0, &f8x13, std8x13_, 8, 0,"That's all folks ;)");

  return 1;
}
void copyIramContent(){
  unsigned char *iram,*iram_end,*sdram;
  int len;

  iram=&_iram_start;
  iram_end=&_iram_end;
  len=(iram_end-iram) + 1;
  sdram=&_real_iram_start;

  debug("copyIramContent() iram=%0.8X sdram=%0.8X len=%d\n",&_iram_start,&_real_iram_start,len);

  for(;len;--len){
    *iram++=*sdram++;
  }
}

void initDisplay(){
  // tweak lcd parameters (screen flip bug workaround)
  *REG_LCD_VSYNC=0x8;

  osdSetComponentConfigA(OSD_VIDEO1, 0);
  osdSetComponentConfigA(OSD_VIDEO2, 0);
  osdSetComponentConfigA(OSD_BITMAP1, 0);
  osdSetComponentConfigA(OSD_BITMAP2, 0);
  osdSetComponentConfigA(OSD_CURSOR1, 0);
  osdSetComponentConfigA(OSD_CURSOR2, 0);

  osdBmp1.offset = OSD_BITMAP1_ADDRESS;
  osdBmp1.bytesPerLine = OSD_BITMAP1_WIDTH;
  osdBmp1.width = OSD_BITMAP1_WIDTH;
  osdBmp1.height = OSD_BITMAP1_HEIGHT;
  osdBmp1.bitsPerPixelShift = 4;
  osdBmp1.bitsPerPixel = 8;

  graphicsBoxfA(&osdBmp1,0,0,OSD_BITMAP1_WIDTH,OSD_BITMAP1_HEIGHT,COL_BLACK);

  osdBmp2.offset = OSD_BITMAP2_ADDRESS;
  osdBmp2.bytesPerLine = OSD_BITMAP2_WIDTH*2;
  osdBmp2.width = LCD_WIDTH;
  osdBmp2.height = OSD_BITMAP2_HEIGHT;
  osdBmp2.bitsPerPixelShift = 4;
  osdBmp2.bitsPerPixel = 16;

  graphicsBoxfA(&osdBmp2,0,0,OSD_BITMAP2_WIDTH,OSD_BITMAP2_HEIGHT,COL_BLACK);


  osdSetMainConfigA(OSD_COMPONENT_ENABLE);
//  osdSetBacklightA(1);

  osdSetComponentSizeA(OSD_BITMAP1, OSD_BITMAP1_WIDTH*2, OSD_BITMAP1_HEIGHT);
  osdSetComponentPositionA(OSD_BITMAP1, LCD_POS_X, LCD_POS_Y);
  osdSetComponentOffsetA(OSD_BITMAP1, OSD_BITMAP1_ADDRESS);
  osdSetComponentSourceWidthA(OSD_BITMAP1, 8);

  osdSetComponentSizeA(OSD_BITMAP2, OSD_BITMAP2_WIDTH*2, OSD_BITMAP2_HEIGHT);
  osdSetComponentPositionA(OSD_BITMAP2, LCD_POS_X, LCD_POS_Y);
  osdSetComponentOffsetA(OSD_BITMAP2, OSD_BITMAP2_ADDRESS);
  osdSetComponentSourceWidthA(OSD_BITMAP2, 15);

  osdSetComponentSizeA(OSD_CURSOR1, 174*2, 159);
  osdSetComponentPositionA(OSD_CURSOR1, LCD_POS_X+16*2, LCD_POS_Y+2);
}

void showOSD(int osd){
  osdSetComponentConfigA(OSD_BITMAP1, 0);
  osdSetComponentConfigA(OSD_BITMAP2, 0);
  showGGBorder(false);

  if (osd==OSD_BITMAP1){
    osdSetComponentConfigA(OSD_BITMAP1,OSD_BITMAP1_CONFIG);
  }else if (osd==OSD_BITMAP2){
    osdSetComponentConfigA(OSD_BITMAP2,OSD_BITMAP2_CONFIG);
  }
}

void initHDD(){
  ataSelectHDDA();
  delay(1000);

  ataPowerUpHDDA();
  ataResetHDDA();
  delay(5000);

  ataReadMBR();

  fat_init();
  fat_mount(getPartition(0)->start);
};

void drawIntro(){
  static int y=0;

  graphicsBoxfA(&osdBmp2,0,0,OSD_BITMAP2_WIDTH,OSD_BITMAP2_HEIGHT,COL_BLACK);

  pal[1]=COL_GREEN;

  graphicsStringA(&osdBmp2, 0, y, &f8x13, std8x13_, 8, 0,"GminiSMS v0.4");

  pal[1]=COL_CYAN;

  y+=15;graphicsStringA(&osdBmp2, 0, y, &f5x7, std5x7_, 5, 0,"by GliGli");

  pal[1]=COL_WHITE;

  y+=15;graphicsStringA(&osdBmp2, 0, y, &f5x7, std5x7_, 5, 0,"A Master System / GameGear emulator");
  y+=7;graphicsStringA(&osdBmp2, 0, y, &f5x7, std5x7_, 5, 0,"based on SMS Plus by Charles MacDonald");

  y+=13;graphicsStringA(&osdBmp2, 0, y, &f5x7, std5x7_, 5, 0,"Browser keys:");
  y+=10;graphicsStringA(&osdBmp2, 0, y, &f5x7, std5x7_, 5, 0,"-Up/Down: move");
  y+=7;graphicsStringA(&osdBmp2, 0, y, &f5x7, std5x7_, 5, 0,"-Left: up one level");
  y+=7;graphicsStringA(&osdBmp2, 0, y, &f5x7, std5x7_, 5, 0,"-Right/Square: open dir/rom");
  y+=7;graphicsStringA(&osdBmp2, 0, y, &f5x7, std5x7_, 5, 0,"-Off: quit");

  y+=13;graphicsStringA(&osdBmp2, 0, y, &f5x7, std5x7_, 5, 0,"Ingame keys:");
  y+=10;graphicsStringA(&osdBmp2, 0, y, &f5x7, std5x7_, 5, 0,"-On: MS pause / GG start");
  y+=7;graphicsStringA(&osdBmp2, 0, y, &f5x7, std5x7_, 5, 0,"-F1: options menu");
  y+=7;graphicsStringA(&osdBmp2, 0, y, &f5x7, std5x7_, 5, 0,"-F2: reset");
  y+=7;graphicsStringA(&osdBmp2, 0, y, &f5x7, std5x7_, 5, 0,"-F3+UDLR: move MS screen / expand GG screen");
  y+=7;graphicsStringA(&osdBmp2, 0, y, &f5x7, std5x7_, 5, 0,"-Off: go to browser");

  graphicsStringA(&osdBmp2, 0, 163, &f8x13, std8x13_, 8, 0,"Loading...");
}

void waitIntroKeyPress(){
  graphicsStringA(&osdBmp2, 0, 163, &f8x13, std8x13_, 8, 0,"Press a key to continue...");
  while((buttonsGetStatusA()&BUTTONS_GM400_ANY)!=0) delay(100); // make sure no button is pressed
  while((buttonsGetStatusA()&BUTTONS_GM400_ANY)==0) delay(100); // wait until a button is pressed
  while((buttonsGetStatusA()&BUTTONS_GM400_ANY)!=0) delay(100); // wait until it is released
}

void initSmsEmul(){
  sms.use_fm = false;
  sms.country = TYPE_OVERSEAS;
  sms.save = false;

  bitmap.width  = OSD_BITMAP1_WIDTH;
  bitmap.height = OSD_BITMAP1_HEIGHT;
  bitmap.depth  = 8;
  bitmap.pitch  = OSD_BITMAP1_WIDTH;
  bitmap.data   = (unsigned char*)OSD_BITMAP1_ADDRESS;

  snd.enabled=false;
  snd.log=false;
  snd.bufsize=0;

  cart.rom=bget(MAX_ROM_SIZE);

  system_init(0);
}

bool loadRom(char *romname){
  int f,cnt;

  f=open(romname,O_RDONLY);
  if (f<0) return false;

  lseek(f,filesize(f)%SMS_BANK_SIZE,SEEK_SET); // skip header if there is one

  cnt=read(f,cart.rom,MAX_ROM_SIZE);

  cart.pages=cnt/SMS_BANK_SIZE;
  cart.type=TYPE_SMS;

  if (strstr(romname,".GG") || strstr(romname,".gg")) cart.type=TYPE_GG;

  close(f);

  debug("rom loaded, %d pages\n",cart.pages);
  return cnt>0;
}

void doEmulLoop(){
  int i,prevTick,frameTickDelta,frameTick;
  int bt;
  int framenum,plop;
  unsigned int ycbcr,y,cb,cr;

  framenum=0;
  plop=0;
  input.pad[1]=0;
  prevTick=getTickCount();
  do{
    bt=buttonsGetStatusA();

    input.pad[0]=(bt>>4) & 0xf; // directions

    if(swapButtons){
      if(bt&BUTTONS_GM400_SQUARE) input.pad[0]|=INPUT_BUTTON2;
      if(bt&BUTTONS_GM400_CROSS) input.pad[0]|=INPUT_BUTTON1;
    }else{
      if(bt&BUTTONS_GM400_SQUARE) input.pad[0]|=INPUT_BUTTON1;
      if(bt&BUTTONS_GM400_CROSS) input.pad[0]|=INPUT_BUTTON2;
    }

    input.system=0;

    if (bt&BUTTONS_GM400_ON){
      if (cart.type==TYPE_SMS){
        input.system|=INPUT_PAUSE;
      }else{
        input.system|=INPUT_START;
      }
    }

    if (bt&BUTTONS_GM400_MENU1){
      doIngameMenu();
    }

    if (bt&BUTTONS_GM400_MENU2){
      input.system|=INPUT_HARD_RESET;
    }

    if (bt&BUTTONS_GM400_MENU3){
      if (cart.type==TYPE_SMS){
        moveVirtualScreen();
      }else{
        configWriteBool("ExpandGGScreen",!configReadBool("ExpandGGScreen"));
        while((buttonsGetStatusA()&BUTTONS_GM400_ANY)!=0) delay(100); // make sure no button is pressed
        applyConfig();
      }
    }

    for(i=0;i<frameSkip;++i){
      sms_frame(1);
    }
/*
    plop=!plop;
    if (plop){
      osdSetComponentOffsetA(OSD_BITMAP1, OSD_BITMAP1_ADDRESS_2+OSD_BITMAP1_WIDTH*vsPosY);
      bitmap.data = (unsigned char*)OSD_BITMAP1_ADDRESS;
    }else{
      osdSetComponentOffsetA(OSD_BITMAP1, OSD_BITMAP1_ADDRESS+OSD_BITMAP1_WIDTH*vsPosY);
      bitmap.data = (unsigned char*)OSD_BITMAP1_ADDRESS_2;
    }
*/

    if (bitmap.pal.update){
      for(i=0;i<32;++i){
        if(bitmap.pal.dirty[i]){
          ycbcr=graphicsRGB2PackedA(bitmap.pal.color[i][0],bitmap.pal.color[i][1],bitmap.pal.color[i][2]);

          y=(ycbcr>>8) & 0xff;
          cb=(ycbcr>>16) & 0xff;
          cr=ycbcr & 0xff;

          osdSetPalletteA(y,cb,cr,i);
          osdSetPalletteA(y,cb,cr,i+0x20);
          osdSetPalletteA(y,cb,cr,i+0x40);

          bitmap.pal.dirty[i]=false;
        }
      }
      bitmap.pal.update=false;
    }

    sms_frame(0);

    frameTick=getTickCount()-prevTick;
//    debug("%d\n",frameTick);
    frameTickDelta=((frameSkip+1)*TICKS_PER_FRAME)-frameTick;
//    debug("%d %d\n",frameTickDelta,frameSkip);
    if (frameTickDelta>0) delay(frameTickDelta);
    if (autoFrameSkip){
      if (frameTickDelta>0) --frameSkip;
      if (frameTickDelta<-20) ++frameSkip;
    };
    prevTick=getTickCount();

    framenum++;
  }while(!(bt&BUTTONS_GM400_OFF));
}

void setVirtualScreenPos(){
  // change plane position
  osdSetComponentPositionA(OSD_BITMAP1, LCD_POS_X-vsPosX, LCD_POS_Y);
  osdSetComponentOffsetA(OSD_BITMAP1, OSD_BITMAP1_ADDRESS+OSD_BITMAP1_WIDTH*vsPosY);

  //change emu rendering window
  if(cart.type==TYPE_SMS || !ggBorder){
    vp_vstart=vsPosY;
    vp_vend=OSD_BITMAP1_HEIGHT-MAX_VS_POS_Y+vsPosY;

    vp_hstart=vsPosX;
    if ((vp_hstart%16)>0){
      vp_hstart=(vp_hstart>>4)-2;
    }else{
      vp_hstart=(vp_hstart>>4)-1;
    }

    vp_hend=(OSD_BITMAP1_WIDTH<<1)-MAX_VS_POS_X+vsPosX;
    if (vp_hend&0xf){
      vp_hend=(vp_hend>>4)+1;
    }else{
      vp_hend=vp_hend>>4;
    }
  }else{
    vp_vstart = 24;
    vp_vend   = 168;
    vp_hstart = 6;
    vp_hend   = 26;
  };
}

void moveVirtualScreen(){
  int bt;

  do{
    bt=buttonsWaitAndRepeat(2500,500,-1);

    if(bt&BUTTONS_GM400_UP) vsPosY-=1;
    if(bt&BUTTONS_GM400_DOWN) vsPosY+=1;
    if(bt&BUTTONS_GM400_LEFT) vsPosX-=2;
    if(bt&BUTTONS_GM400_RIGHT) vsPosX+=2;

    if(vsPosX<0) vsPosX=0;
    if(vsPosY<0) vsPosY=0;

    if(vsPosX>MAX_VS_POS_X) vsPosX=MAX_VS_POS_X;
    if(vsPosY>MAX_VS_POS_Y) vsPosY=MAX_VS_POS_Y;

    setVirtualScreenPos();
  }while(bt&BUTTONS_GM400_MENU3);
}

void showGGBorder(bool show){
  if (cart.type==TYPE_GG && show){
    graphicsBoxfA(&osdBmp1,0,0,OSD_BITMAP1_WIDTH,OSD_BITMAP1_HEIGHT,0); // clear border
    osdSetComponentConfigA(OSD_CURSOR1,OSD_CURSOR1_CONFIG);
  }else{
    osdSetComponentConfigA(OSD_CURSOR1,0);
  }
}

void overclockARM(int rate){
  if(rate==0){
    *REG_ARM_CLOCK=0x80E1; // default ARM clock
  }else{
    *REG_ARM_CLOCK=(0x8070+(rate<<4));
  }
}

void doIngameMenu(){
  int res;

  ingameMenu[2].value=configReadBool("AutoFrameSkip");
  ingameMenu[3].value=configReadInt("FrameSkip");
  ingameMenu[5].value=configReadBool("ButtonsSwap");
  ingameMenu[6].value=configReadBool("SpriteLimit");
  ingameMenu[7].value=configReadBool("ExpandGGScreen");
  ingameMenu[8].value=configReadInt("CyclesPerLine");
  ingameMenu[10].value=configReadBool("Overclocking");
  ingameMenu[11].value=configReadInt("OverclockingRate");

  showOSD(OSD_BITMAP2);
  res=showMenu("GminiSMS options menu (paused):",ingameMenu,sizeof(ingameMenu)/sizeof(tMenuItem),&osdBmp2,&f6x9,std6x9_,NULL);
  showOSD(OSD_BITMAP1);

  configWriteBool("AutoFrameSkip",ingameMenu[2].value);
  configWriteInt("FrameSkip",ingameMenu[3].value);
  configWriteBool("ButtonsSwap",ingameMenu[5].value);
  configWriteBool("SpriteLimit",ingameMenu[6].value);
  configWriteBool("ExpandGGScreen",ingameMenu[7].value);
  configWriteInt("CyclesPerLine",ingameMenu[8].value);
  configWriteBool("Overclocking",ingameMenu[10].value);
  configWriteInt("OverclockingRate",ingameMenu[11].value);

  // state saving/loading
  if(res==2) loadSaveState(ingameMenu[13].value,false);
  if(res==3) loadSaveState(ingameMenu[13].value,true);

  applyConfig();
}

void loadDefaultConfig(){
  configClear();

  configWriteBool("AutoFrameSkip",true);
  configWriteInt("FrameSkip",1);

  configWriteBool("ButtonsSwap",true);
  configWriteBool("SpriteLimit",false);
  configWriteBool("ExpandGGScreen",false);
  configWriteInt("CyclesPerLine",256);

  configWriteBool("Overclocking",false);
  configWriteBool("OverclockingRate",0);
}

void applyConfig(){
  autoFrameSkip=configReadBool("AutoFrameSkip");
  frameSkip=configReadInt("FrameSkip");

  swapButtons=configReadBool("ButtonsSwap");
  vdp.limit=configReadBool("SpriteLimit");
  ggBorder=!configReadBool("ExpandGGScreen");
  sms.cyclesperline=configReadInt("CyclesPerLine");

  if (configReadBool("Overclocking")){ // overclock enabled?
    overclockARM(configReadInt("OverclockingRate"));
  }else{
    overclockARM(0);
  }

  showGGBorder(ggBorder);
  setVirtualScreenPos();
}


void loadSaveState(int slot,bool save){
  char s[255];
  int f;

  if(save){
    sprintf(s,"Saving state, slot %d...",slot);
  }else{
    sprintf(s,"Loading state, slot %d...",slot);
  }

  showOSD(OSD_BITMAP2);
  graphicsBoxfA(&osdBmp2,0,0,OSD_BITMAP1_WIDTH,OSD_BITMAP1_HEIGHT,COL_BLACK);
  graphicsStringA(&osdBmp2, 0, 0, &f8x13, std8x13_, 8, 0,s);

  prepareHDDAccess();

  strcpy(s,romname);
  *strrchr(s,'.')='\0';
  sprintf(s,"%s.st%d",s,slot-1);

  if(save){
    f=creat(s,O_CREAT);
    if (f>=0){
      system_save_state(f);
      close(f);
    }else{
      graphicsStringA(&osdBmp2, 0, 15, &f8x13, std8x13_, 8, 0,"Can't save!");
    }
  }else{
    f=open(s,O_RDONLY);
    if (f>=0){
      system_load_state(f);
      close(f);
    }else{
      graphicsStringA(&osdBmp2, 0, 15, &f8x13, std8x13_, 8, 0,"Not found!");
    }
  }

  endHDDAccess();

  showOSD(OSD_BITMAP1);
}

void loadSaveSram(bool save){
  char s[255];
  int f;

  if(save){
    strcpy(s,"Saving SRAM...");
  }else{
    strcpy(s,"Loading SRAM...");
  }

  showOSD(OSD_BITMAP2);
  graphicsBoxfA(&osdBmp2,0,0,OSD_BITMAP1_WIDTH,OSD_BITMAP1_HEIGHT,COL_BLACK);
  graphicsStringA(&osdBmp2, 0, 0, &f8x13, std8x13_, 8, 0,s);

  strcpy(s,romname);
  *strrchr(s,'.')='\0';
  strcat(s,".sav");

  if(save){
    f=creat(s,O_CREAT);
    if (f>=0){
      write(f,sms_sram,sizeof(sms_sram));
      close(f);
    }
  }else{
    f=open(s,O_RDONLY);
    if (f>=0){
      read(f,sms_sram,sizeof(sms_sram));
      close(f);
    }
  }
}

void prepareHDDAccess(){
  overclockARM(0); // safer not to overclock during HDD access

  ataPowerUpHDDA();
}

void endHDDAccess(){
  ataSleepCmdA();
  ataPowerDownHDDA();

  overclockARM(configReadInt("OverclockingRate"));

  while((buttonsGetStatusA()&BUTTONS_GM400_ANY)!=0) delay(100); // workaround button bug
}

void drawProgress(int offset,int length,int mode){}
