/*

 All files in this archive are subject to the GNU General Public License.
 See the file COPYING in the source tree root for full license agreement.
 This software is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY
 KIND, either express of implied.

 Real Time Clock test program

 Date:     11/10/2005
 Author:   GliGli

*/

#include <uart.h>
#include <string.h>
#include <graphics.h>
#include <osdDSC25.h>
#include <buttons.h>
#include <fonts.h>
#include <rtc.h>
#include <timers.h>
#include <stdbool.h>

#include <tickcount.h>

#define LCD_WIDTH 220
#define LCD_HEIGHT 176

#define OSD_BITMAP1_WIDTH 240
#define OSD_BITMAP1_HEIGHT 176

#define OSD_BITMAP1_ADDRESS 0x018d1500


static int pal32[2] = {
    0x8080c0e0, 0xffffffff
};
static int pal16[2] = {
    0x0000, 0xffff
};

struct graphicsBuffer screenBitmap;
char data[512];
struct graphicsBuffer sprite4_6 = {0, 1, 4, 6, 1, 0, -1, 0, 0, 0, 0, (int**) &pal16, (int**) &pal32};
struct graphicsBuffer spriteShadow = {0, 2, 12, 18, 1, 0, -1, 0, 0, 0, 0, (int**) &pal16, (int**) &pal32};
int addr= 0xd0;             // 0x3c, 0x90, 0xd0

struct tm* ourTime;
char timeSt[] = "xx:xx:xx.xx";

int int2bcd(int v){
  return ((v % 10) + (((int) (v / 10)) << 4));
}


int bcd2int(int v){
  return ((v & 0xf0) >> 4) * 10 + (v & 0xf);
}


void initDisplay();

int main() {
    int b;
    char s[100];

    rtcInit();

    initTickCount();

    initDisplay();

    pal16[1] = 0x0202;

    graphicsStringA(&screenBitmap, 0, 0, &sprite4_6, std4x6_, 5, 0, "F1: set hour F2: set min F3: set sec");

    while(1) {
        uartOutsA(UART_0, "rtcGetTime()\r\n");
        ourTime = rtcGetTime();
        uartOutsA(UART_0, "Ret\r\n");
        pal16[1] = 0xffff;

        sprintf(s,"%.2x:%.2x:%.2x.%.2x",ourTime->tm_hour,ourTime->tm_min,ourTime->tm_sec,ourTime->tm_ms);
        graphicsStringA(&screenBitmap, 110-(5*14)-7, 68, &spriteShadow, shadow_, 14, 0, s);

        sprintf(s,"%.2x/%.2x/%.2x",ourTime->tm_mday,ourTime->tm_mon,ourTime->tm_year);
        graphicsStringA(&screenBitmap, 110-(4*14)-7, 108, &spriteShadow, shadow_, 14, 0, s);

        uartOutsA(UART_0, "Loop\r\n");
        b = buttonsGetStatusA();
        if (b & BUTTONS_GM400_OFF) return 0;
        if (b & BUTTONS_GM400_MENU1){
          ourTime->tm_hour=int2bcd((bcd2int(ourTime->tm_hour)+1)%24);
          rtcSetTime(*ourTime);
          delay(1000);
        }
        if (b & BUTTONS_GM400_MENU2){
          ourTime->tm_min=int2bcd((bcd2int(ourTime->tm_min)+1)%60);
          rtcSetTime(*ourTime);
          delay(1000);
        }
        if (b & BUTTONS_GM400_MENU3){
          ourTime->tm_sec=int2bcd((bcd2int(ourTime->tm_sec)+1)%60);
          rtcSetTime(*ourTime);
          delay(1000);
        }
    }
  return 0;
}



void initDisplay(){

  osdSetComponentConfigA(OSD_VIDEO1, 0);
  osdSetComponentConfigA(OSD_VIDEO1, 0);
  osdSetComponentConfigA(OSD_BITMAP1, 0);
  osdSetComponentConfigA(OSD_BITMAP2, 0);
  osdSetComponentConfigA(OSD_CURSOR1, 0);
  osdSetComponentConfigA(OSD_CURSOR2, 0);

  screenBitmap.offset = OSD_BITMAP1_ADDRESS;
  screenBitmap.bytesPerLine = OSD_BITMAP1_WIDTH*2;
  screenBitmap.width = OSD_BITMAP1_WIDTH;
  screenBitmap.height = OSD_BITMAP1_HEIGHT;
  screenBitmap.bitsPerPixelShift = 4;
  screenBitmap.bitsPerPixel = 16;

  graphicsBoxfA(&screenBitmap,0,0,OSD_BITMAP1_WIDTH,OSD_BITMAP1_HEIGHT,0x0000);

  osdSetMainConfigA(1);
  osdSetBacklightA(1);

  osdSetComponentSizeA(OSD_BITMAP1, OSD_BITMAP1_WIDTH*2, OSD_BITMAP1_HEIGHT);
  osdSetComponentPositionA(OSD_BITMAP1, 0xfc, 0x18);
  osdSetComponentOffsetA(OSD_BITMAP1, OSD_BITMAP1_ADDRESS);
  osdSetComponentSourceWidthA(OSD_BITMAP1, 0xf);
  osdSetComponentConfigA(OSD_BITMAP1, OSD_COMPONENT_ENABLE
                                   | OSD_BITMAP_8BIT
                                   | OSD_BITMAP_0TRANS
                                   );


}

