/*

 All files in this archive are subject to the GNU General Public License.
 See the file COPYING in the source tree root for full license agreement.
 This software is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY
 KIND, either express of implied.

 Gameboy / Color Gameboy emulator (port of gnuboy)

 Date:     18/10/2005
 Author:   GliGli

*/

#include "string.h"
#include <ata.h>
#include <fat.h>
#include <file.h>
#include <system.h>
#include <graphics.h>
#include <osdDSC25.h>
#include <buttons.h>
#include <fonts.h>
#include <debug.h>
#include <usb.h>
#include <timers.h>
#include <avmalloc.h>

#include <tickcount.h>
#include <filebrowser.h>

#include <stdarg.h>

#define LCD_WIDTH 220
#define LCD_HEIGHT 176

#define OSD_BITMAP1_WIDTH 160
#define OSD_BITMAP1_HEIGHT 144

#define OSD_BITMAP1_CONFIG  OSD_COMPONENT_ENABLE | OSD_BITMAP_8BIT | OSD_BITMAP_MERGEBACK | OSD_BITMAP_A7 | OSD_BITMAP_ZX1 | OSD_BITMAP_RAMCLUT

#define OSD_BITMAP1_ADDRESS 0x018d1500

#include "defs.h"
#include "regs.h"

#include "lcd.h"

#include "fb.h"
#include "input.h"
#include "pcm.h"
#include "mem.h"
#include "hw.h"
#include "rtc.h"
#include "sound.h"

char _real_iram_start;
char _iram_start;
char _iram_end;

static struct graphicsBuffer osdBmp1;

static int pal[2] = {0x0000, 0xffff};

static struct graphicsBuffer f6x9  = {0, 1, 6, 9, 1, 0, -1, 0, 0, 0, 0, (int**) &pal, (int**) NULL};

struct fb fb;
struct pcm pcm;

void initDisplay();
void initHDD();
void copyIramContent();

int main(){
//  char* rom="/tetris.gb";
//  char* rom="/sml1.gb";
  char* rom="/sml2.gb";
//  char* rom="/dkl.gb";
//  char* rom="/vr.gbc";

  bpool(0x1000000,0x400000);

  copyIramContent();
  initTickCount();
  initDisplay();
  initHDD();

  vid_init();
	pcm_init();

	loader_init(rom);

	emu_reset();
	emu_run();

  return 0;
}


void copyIramContent(){
  unsigned char *iram,*iram_end,*sdram;
  int len;

  iram=&_iram_start;
  iram_end=&_iram_end;
  len=(iram_end-iram) + 1;
  sdram=&_real_iram_start;

  debug("copyIramContent() iram=%0.8X sdram=%0.8X len=%d\n",&_iram_start,&_real_iram_start,len);

  for(;len;--len){
    *iram++=*sdram++;
  }
}

void initDisplay(){

  osdSetComponentConfigA(OSD_VIDEO1, 0);
  osdSetComponentConfigA(OSD_VIDEO1, 0);
  osdSetComponentConfigA(OSD_BITMAP1, 0);
  osdSetComponentConfigA(OSD_BITMAP2, 0);
  osdSetComponentConfigA(OSD_CURSOR1, 0);
  osdSetComponentConfigA(OSD_CURSOR2, 0);

  osdBmp1.offset = OSD_BITMAP1_ADDRESS;
  osdBmp1.bytesPerLine = OSD_BITMAP1_WIDTH;
  osdBmp1.width = LCD_WIDTH;
  osdBmp1.height = OSD_BITMAP1_HEIGHT;
  osdBmp1.bitsPerPixelShift = 4;
  osdBmp1.bitsPerPixel = 8;

  graphicsBoxfA(&osdBmp1,0,0,OSD_BITMAP1_WIDTH,OSD_BITMAP1_HEIGHT,0x0000);

  osdSetMainConfigA(1);
//  osdSetBacklightA(1);

  osdSetComponentSizeA(OSD_BITMAP1, OSD_BITMAP1_WIDTH*2, OSD_BITMAP1_HEIGHT);
  osdSetComponentPositionA(OSD_BITMAP1, 0xfc+60, 0x18+16);
  osdSetComponentOffsetA(OSD_BITMAP1, OSD_BITMAP1_ADDRESS);
  osdSetComponentSourceWidthA(OSD_BITMAP1, 5);
  osdSetComponentConfigA(OSD_BITMAP1,OSD_BITMAP1_CONFIG);


}

void initHDD(){
    int c;

    ataSelectHDDA();
    for (c=0;c<0x1000;c++) {}

    ataPowerUpHDDA();
    ataResetHDDA();
    for (c=0;c<0x24000;c++) {}

    ataReadMBR();

    fat_init();
    fat_mount(getPartition(0)->start);
};

void vid_preinit(void){
  debug("vid_preinit\n");
}

void vid_init(void){
  debug("vid_init\n");

  fb.w = OSD_BITMAP1_WIDTH;
  fb.h = OSD_BITMAP1_HEIGHT;
  fb.pelsize = 1;
  fb.pitch = OSD_BITMAP1_WIDTH;
  fb.ptr = (unsigned char *)OSD_BITMAP1_ADDRESS;;
  fb.enabled = 1;
  fb.dirty = 0; ///1????
  fb.yuv = 0;
  fb.indexed = 1;
}

int framenum=0;

void vid_begin(void){
//  debug("vid_begin\n");
  framenum=(framenum+1)%2;
	fb.enabled=!framenum;
}
void vid_end(void){
//  debug("vid_end\n");
}
void vid_close(void){
  debug("vid_close\n");
}
void vid_settitle(void){
  debug("vid_settitle\n");
}
void vid_setpal(int i, int r, int g, int b){
  unsigned int ycbcr,y,cb,cr;

  debug("vid_setpal %d %d %d %d\n",i,r,g,b);

  ycbcr=graphicsRGB2PackedA(r,g,b);

  y=(ycbcr>>8) & 0xff;
  cb=(ycbcr>>16) & 0xff;
  cr=ycbcr & 0xff;

  osdSetPalletteA(y,cb,cr,i);
}

int oldbt=0;

bool doevents(void){
  int bt,pressed,released;
  event_t ev;

  bt=buttonsGetStatusA();
  pressed=bt & ~oldbt;
  released=~bt & oldbt;
  oldbt=bt;

//  debug("%0.8x %0.8x\n",pressed,released);

  if (pressed){
    if(pressed & BUTTONS_GM400_UP)     pad_press(PAD_UP);
    if(pressed & BUTTONS_GM400_DOWN)   pad_press(PAD_DOWN);
    if(pressed & BUTTONS_GM400_LEFT)   pad_press(PAD_LEFT);
    if(pressed & BUTTONS_GM400_RIGHT)  pad_press(PAD_RIGHT);
    if(pressed & BUTTONS_GM400_CROSS)  pad_press(PAD_B);
    if(pressed & BUTTONS_GM400_SQUARE) pad_press(PAD_A);
    if(pressed & BUTTONS_GM400_ON)     pad_press(PAD_START);
    if(pressed & BUTTONS_GM400_MENU1)  pad_press(PAD_SELECT);
  }

  if (released){
    if(released & BUTTONS_GM400_UP)     pad_release(PAD_UP);
    if(released & BUTTONS_GM400_DOWN)   pad_release(PAD_DOWN);
    if(released & BUTTONS_GM400_LEFT)   pad_release(PAD_LEFT);
    if(released & BUTTONS_GM400_RIGHT)  pad_release(PAD_RIGHT);
    if(released & BUTTONS_GM400_CROSS)  pad_release(PAD_B);
    if(released & BUTTONS_GM400_SQUARE) pad_release(PAD_A);
    if(released & BUTTONS_GM400_ON)     pad_release(PAD_START);
    if(released & BUTTONS_GM400_MENU1)  pad_release(PAD_SELECT);
  }

  return !(bt&BUTTONS_GM400_OFF);
}

void pcm_init(void){
  debug("pcm_init\n");

	pcm.hz = 0;
	pcm.stereo = 0;
	pcm.buf = NULL;
	pcm.len = 0;
	pcm.pos = 0;
}

int pcm_submit(){
//  debug("pcm_submit\n");
	pcm.pos = 0;
	return 1;
}

void pcm_close(void){
  debug("pcm_close\n");
}


void *sys_timer(){
//  debug("sys_timer\n");
  return getTickCount()*100;
}

int sys_elapsed(void){
  static int prevtc=0;
  int delta;
  delta=getTickCount()-prevtc;
  prevtc=getTickCount();
  return delta*100;
} 

void  sys_sleep(int us){
//  debug("sys_sleep\n");
  delay(us*100);
}

void  sys_checkdir(char *path, int wr){
  debug("sys_checkdir\n");
}

void  sys_initpath(char *exe){
  debug("sys_initpath\n");
}

void  sys_sanitize(char *s){
  debug("sys_sanitize\n");
}

void die(char *fmt, ...)
{
  static char err[200];


	va_list ap;

	va_start(ap, fmt);
	vsnprintf(err,sizeof(err), fmt, ap);
	va_end(ap);
	
	debug("DIE!: %s\n",err);
	for(;;);
}

void drawProgress(int offset,int length,int mode){};

