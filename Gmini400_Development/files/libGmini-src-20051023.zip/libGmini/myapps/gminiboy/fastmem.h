
#ifndef __FASTMEM_H__
#define __FASTMEM_H__


#include "defs.h"
#include "mem.h"


__IRAM_CODE static byte readb(int a)
{
	byte *p = mbc.rmap[a>>12];
	if (p) return p[a];
	else return mem_read(a);
}

__IRAM_CODE static void writeb(int a, byte b)
{
	byte *p = mbc.wmap[a>>12];
	if (p) p[a] = b;
	else mem_write(a, b);
}

__IRAM_CODE static int readw(int a)
{
	if ((a+1) & 0xfff)
	{
		byte *p = mbc.rmap[a>>12];
		if (p)
		{
			if (a&1) return p[a] | (p[a+1]<<8);
			return *(word *)(p+a);
//			return p[a] | (p[a+1]<<8);
		}
	}
	return mem_read(a) | (mem_read(a+1)<<8);
}

__IRAM_CODE static void writew(int a, int w)
{
	if ((a+1) & 0xfff)
	{
		byte *p = mbc.wmap[a>>12];
		if (p)
		{
			if (a&1)
			{
				p[a] = w;
				p[a+1] = w >> 8;
				return;
			}
			*(word *)(p+a) = w;
			return;
//			p[a] = w;
//    	p[a+1] = w >> 8;
//			return;
//#endif
		}
	}
	mem_write(a, w);
	mem_write(a+1, w>>8);
}

__IRAM_CODE static byte readhi(int a)
{
	return readb(a | 0xff00);
}

__IRAM_CODE static void writehi(int a, byte b)
{
	writeb(a | 0xff00, b);
}

#if 0
static byte readhi(int a)
{
	byte (*rd)() = hi_read[a];
	return rd ? rd(a) : (ram.hi[a] | himask[a]);
}

static void writehi(int a, byte b)
{
	byte (*wr)() = hi_write[a];
	if (wr) wr(a, b);
	else ram.hi[a] = b & ~himask[a];
}
#endif


#endif
