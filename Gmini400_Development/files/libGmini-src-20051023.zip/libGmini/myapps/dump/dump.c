/*

 All files in this archive are subject to the GNU General Public License.
 See the file COPYING in the source tree root for full license agreement.
 This software is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY
 KIND, either express of implied.

 Will dump the sdram content to a file

 Date:     11/10/2005
 Author:   GliGli

*/

#include "string.h"
#include <ata.h>
#include <fat.h>
#include <file.h>
#include <system.h>
#include <graphics.h>
#include <osdDSC25.h>
#include <buttons.h>
#include <fonts.h>
#include <debug.h>
#include <usb.h>
#include <timers.h>

#include <filebrowser.h>
#include <tickcount.h>

#define LCD_WIDTH 220
#define LCD_HEIGHT 176

#define OSD_BITMAP1_WIDTH 240
#define OSD_BITMAP1_HEIGHT 176

#define OSD_BITMAP1_ADDRESS 0x018d1500

static struct graphicsBuffer osdBmp1;

static int pal[2] = {0x0000, 0xffff};

//static struct graphicsBuffer f5x7  = {0, 1, 5, 7, 1, 0, -1, 0, 0, 0, 0, (int**) &pal, (int**) NULL};
static struct graphicsBuffer f6x9  = {0, 1, 6, 9, 1, 0, -1, 0, 0, 0, 0, (int**) &pal, (int**) NULL};
//static struct graphicsBuffer f8x13 = {0, 1, 8, 13, 1, 0, -1, 0, 0, 0, 0, (int**) &pal, (int**) NULL};

void initDisplay();
void initHDD();

int main(){
  int f;

  initTickCount();
  initDisplay();
  initHDD();

  graphicsStringA(&osdBmp1, 0, 0, &f6x9, std6x9_, 6, 0,"WAIT");

  f=creat("/ram.dat",O_CREAT);
  write(f,(unsigned char *)0x900000,1024*1024*16);
  close(f);

  graphicsStringA(&osdBmp1, 0, 0, &f6x9, std6x9_, 6, 0,"DONE");

  return 0;
}

void initDisplay(){

  osdSetComponentConfigA(OSD_VIDEO1, 0);
  osdSetComponentConfigA(OSD_VIDEO1, 0);
  osdSetComponentConfigA(OSD_BITMAP1, 0);
  osdSetComponentConfigA(OSD_BITMAP2, 0);
  osdSetComponentConfigA(OSD_CURSOR1, 0);
  osdSetComponentConfigA(OSD_CURSOR2, 0);

  osdBmp1.offset = OSD_BITMAP1_ADDRESS;
  osdBmp1.bytesPerLine = OSD_BITMAP1_WIDTH*2;
  osdBmp1.width = OSD_BITMAP1_WIDTH;
  osdBmp1.height = OSD_BITMAP1_HEIGHT;
  osdBmp1.bitsPerPixelShift = 4;
  osdBmp1.bitsPerPixel = 16;

  graphicsBoxfA(&osdBmp1,0,0,OSD_BITMAP1_WIDTH,OSD_BITMAP1_HEIGHT,0x0000);

  osdSetMainConfigA(1);
  osdSetBacklightA(1);

  osdSetComponentSizeA(OSD_BITMAP1, OSD_BITMAP1_WIDTH*2, OSD_BITMAP1_HEIGHT);
  osdSetComponentPositionA(OSD_BITMAP1, 0xfc, 0x18);
  osdSetComponentOffsetA(OSD_BITMAP1, OSD_BITMAP1_ADDRESS);
  osdSetComponentSourceWidthA(OSD_BITMAP1, 0xf);
  osdSetComponentConfigA(OSD_BITMAP1, OSD_COMPONENT_ENABLE
                                   | OSD_BITMAP_8BIT
                                   | OSD_BITMAP_0TRANS
                                   );


}

void initHDD(){
  ataSelectHDDA();
  delay(1000);

  ataPowerUpHDDA();
  ataResetHDDA();
  delay(5000);

  ataReadMBR();

  fat_init();
  fat_mount(getPartition(0)->start);
};

void drawProgress(int offset,int length,int mode){};
